import 'package:path/path.dart' as p;

class Track {
  const Track({
    required this.path,
    required this.title,
    this.artist = 'Unknown artist',
  });

  /// Title comes from the filename; "Artist - Title" names are split.
  factory Track.fromPath(String path) {
    final base = p.basenameWithoutExtension(path);
    final i = base.indexOf(' - ');
    if (i > 0 && i < base.length - 3) {
      return Track(
        path: path,
        title: base.substring(i + 3).trim(),
        artist: base.substring(0, i).trim(),
      );
    }
    return Track(path: path, title: base);
  }

  factory Track.fromJson(Map<String, dynamic> j) => Track(
        path: j['path'] as String,
        title: j['title'] as String,
        artist: (j['artist'] as String?) ?? 'Unknown artist',
      );

  final String path;
  final String title;
  final String artist;

  String get id => path;
  String get fileName => p.basename(path);

  Map<String, dynamic> toJson() => {
        'path': path,
        'title': title,
        'artist': artist,
      };
}
