# Feature status (Android only)

Nothing here has been compiled or run by the author of this file. "Unit-tested" means tests were written, not that they have passed. Check CI.

## Implemented (written, unverified)
- Add audio files via picker, local library, search (title/artist/filename), sort, favorites, recents, playlists (all persisted in local preferences)
- Playback via just_audio: play/pause/seek/next/previous, queue (add/remove/reorder/clear/next-up), shuffle, repeat off/all/one, background playback + media notification (just_audio_background)
- Speed and pitch, "Slowed" preset, 5-band system equalizer with presets and custom presets, volume boost 100-300% (Android LoudnessEnhancer)
- Lyrics: paste/edit, import .lrc/.txt, synced highlight, sidecar .lrc discovery, font size
- Player layouts: vinyl (spin toggle), album, minimal; dark/AMOLED/light, accent color, performance mode

## NOT implemented
- Embedded tag reading (titles come from filenames; "Artist - Title" is split)
- Reading embedded tags/artwork; metadata editor (display-only or file)
- Reverb (so no "Slowed + Reverb"), bass/treble/balance/fades/compressor/crossfade/normalization
- Offline AI equalizer, audio-reactive visualizer, DJ mode, fullscreen visualizer
- SQLite (library uses SharedPreferences JSON), album search, signed release builds
- Windows (dropped by request)

## Added
- Scan whole device (internal + SD card) or a chosen folder for audio files (mp3, m4a, aac, ogg, opus, wav, flac, aiff, wma, ape, amr, mka, 3gp, midi). Runs in the background; skips hidden folders, Android/ and files under 64 KB. Listing a format does not guarantee Android can decode it.
