package com.vibeation.vibe_ation

import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AudioServiceActivity() {
    private val executor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.vibeation/tags")
            .setMethodCallHandler { call, result ->
                if (call.method == "read") {
                    val path = call.argument<String>("path")
                    if (path == null) {
                        result.error("ARG", "path missing", null)
                        return@setMethodCallHandler
                    }
                    executor.execute {
                        val out = readTags(path)
                        mainHandler.post { result.success(out) }
                    }
                } else {
                    result.notImplemented()
                }
            }
    }

    private fun readTags(path: String): HashMap<String, Any?> {
        val map = HashMap<String, Any?>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            map["title"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            map["artist"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            map["album"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            map["albumArtist"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            map["genre"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            map["year"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
            map["durationMs"] =
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            val pic = r.embeddedPicture
            if (pic != null) {
                val dir = File(cacheDir, "art")
                dir.mkdirs()
                val f = File(dir, "${path.hashCode()}_${File(path).length()}.jpg")
                if (!f.exists()) f.writeBytes(pic)
                map["artPath"] = f.absolutePath
            }
        } catch (e: Exception) {
            map["error"] = e.message
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
        return map
    }
}
