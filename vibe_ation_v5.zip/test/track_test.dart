import 'package:flutter_test/flutter_test.dart';
import 'package:vibe_ation/core/models/track.dart';

void main() {
  test('withTags applies real tags and marks tagged', () {
    final t = Track.fromPath('/m/song.mp3');
    expect(t.tagged, isFalse);
    final u = t.withTags(
      const TrackTags(
        title: 'Real Title',
        artist: 'Real Artist',
        album: 'Real Album',
        durationMs: 215000,
        artPath: '/cache/art/1.jpg',
      ),
    );
    expect(u.title, 'Real Title');
    expect(u.artist, 'Real Artist');
    expect(u.album, 'Real Album');
    expect(u.durationMs, 215000);
    expect(u.artPath, '/cache/art/1.jpg');
    expect(u.tagged, isTrue);
    expect(u.subtitle, 'Real Artist \u2022 Real Album');
  });

  test('missing tags keep filename values; null tags still mark tagged', () {
    final t = Track.fromPath('/m/Adele - Hello.mp3');
    final u = t.withTags(const TrackTags(title: null, artist: null));
    expect(u.title, 'Hello');
    expect(u.artist, 'Adele');
    final n = t.withTags(null);
    expect(n.tagged, isTrue);
    expect(n.title, 'Hello');
  });

  test('TrackTags.fromMap trims, drops blanks and reads duration', () {
    final tags = TrackTags.fromMap({
      'title': '  Hi ',
      'artist': '   ',
      'durationMs': 1234,
      'artPath': '/a.jpg',
    });
    expect(tags.title, 'Hi');
    expect(tags.artist, isNull);
    expect(tags.durationMs, 1234);
    expect(tags.artPath, '/a.jpg');
  });

  test('Track json round trip keeps album, duration, art and tagged', () {
    const t = Track(
      path: '/m/a.flac',
      title: 'A',
      artist: 'B',
      album: 'C',
      durationMs: 5,
      artPath: '/x.jpg',
      tagged: true,
    );
    final r = Track.fromJson(t.toJson());
    expect(r.album, 'C');
    expect(r.durationMs, 5);
    expect(r.artPath, '/x.jpg');
    expect(r.tagged, isTrue);
  });
}
