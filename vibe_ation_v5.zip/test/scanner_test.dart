import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:vibe_ation/features/library/scanner.dart';

void main() {
  test('isAudioPath recognises common audio types', () {
    for (final e in ['mp3', 'FLAC', 'm4a', 'opus', 'wav', 'ogg', 'aac']) {
      expect(isAudioPath('/x/song.$e'), isTrue, reason: e);
    }
    expect(isAudioPath('/x/photo.jpg'), isFalse);
    expect(isAudioPath('/x/noext'), isFalse);
  });

  test('scanDirectories finds nested audio, skips hidden/small/non-audio', () {
    final root = Directory.systemTemp.createTempSync('vibe_scan');
    addTearDown(() => root.deleteSync(recursive: true));
    final big = List<int>.filled(kMinAudioBytes + 10, 0);
    File('${root.path}/a.mp3').writeAsBytesSync(big);
    Directory('${root.path}/sub/deep').createSync(recursive: true);
    File('${root.path}/sub/deep/b.flac').writeAsBytesSync(big);
    File('${root.path}/tiny.mp3').writeAsBytesSync([1, 2, 3]);
    File('${root.path}/pic.jpg').writeAsBytesSync(big);
    Directory('${root.path}/.hidden').createSync();
    File('${root.path}/.hidden/c.mp3').writeAsBytesSync(big);

    final found = scanDirectories([root.path]);
    expect(found.length, 2);
    expect(found.any((p) => p.endsWith('a.mp3')), isTrue);
    expect(found.any((p) => p.endsWith('b.flac')), isTrue);
  });

  test('missing root does not throw', () {
    expect(scanDirectories(['/definitely/not/here']), isEmpty);
  });
}
