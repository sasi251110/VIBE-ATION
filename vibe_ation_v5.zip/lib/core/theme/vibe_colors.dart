import 'package:flutter/material.dart';

/// VIBE-ATION palette (from the Stitch design, Material 3 dark).
class VibeColors {
  const VibeColors._();

  static const Color violet = Color(0xFFA078FF);
  static const Color lavender = Color(0xFFD0BCFF);
  static const Color cyan = Color(0xFF5DE6FF);
  static const Color pink = Color(0xFFF751A1);
  static const Color softPink = Color(0xFFFFB0CD);
  static const Color black = Color(0xFF000000);
  static const Color background = Color(0xFF131318);
  static const Color surfaceLow = Color(0xFF1B1B21);
  static const Color surfaceContainer = Color(0xFF1F1F25);
  static const Color surfaceHigh = Color(0xFF2A292F);
  static const Color onSurface = Color(0xFFE4E1E9);
  static const Color onSurfaceVariant = Color(0xFFCBC3D7);
  static const Color outline = Color(0xFF958EA0);
  static const Color outlineVariant = Color(0xFF494454);
  static const Color lightBackground = Color(0xFFF6F5FA);

  /// Accent choices offered in Settings.
  static const List<Color> accents = [
    violet,
    lavender,
    cyan,
    pink,
    Color(0xFF22C55E),
    Color(0xFFF59E0B),
  ];
}

/// Card surface colour that follows the active theme mode.
Color vibeCard(BuildContext c) {
  final t = Theme.of(c);
  if (t.brightness == Brightness.light) return Colors.white;
  return t.scaffoldBackgroundColor == VibeColors.black
      ? const Color(0xFF121216)
      : VibeColors.surfaceContainer;
}

/// Slightly lighter surface for chips, inputs and nested cards.
Color vibeCardHigh(BuildContext c) {
  final t = Theme.of(c);
  if (t.brightness == Brightness.light) return const Color(0xFFEDEBF5);
  return t.scaffoldBackgroundColor == VibeColors.black
      ? const Color(0xFF1C1C22)
      : VibeColors.surfaceHigh;
}
