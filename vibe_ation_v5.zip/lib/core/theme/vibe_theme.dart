import 'package:flutter/material.dart';

import 'theme_settings.dart';
import 'vibe_colors.dart';

ThemeData buildVibeTheme(ThemeSettings s) {
  final isLight = s.mode == VibeThemeMode.light;
  final brightness = isLight ? Brightness.light : Brightness.dark;

  final Color background;
  final Color surface;
  switch (s.mode) {
    case VibeThemeMode.light:
      background = VibeColors.lightBackground;
      surface = Colors.white;
    case VibeThemeMode.amoled:
      background = VibeColors.black;
      surface = VibeColors.black;
    case VibeThemeMode.dark:
      background = VibeColors.background;
      surface = VibeColors.background;
  }

  var scheme = ColorScheme.fromSeed(
    seedColor: s.accent,
    brightness: brightness,
  ).copyWith(primary: s.accent, secondary: VibeColors.cyan, surface: surface);
  if (!isLight) {
    scheme = scheme.copyWith(
      tertiary: VibeColors.softPink,
      onSurface: VibeColors.onSurface,
      onSurfaceVariant: VibeColors.onSurfaceVariant,
      outline: VibeColors.outline,
      outlineVariant: VibeColors.outlineVariant,
    );
  }

  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: isLight ? Colors.white : const Color(0xFF0E0E13),
      indicatorColor: s.accent.withOpacity(0.25),
    ),
    navigationRailTheme: NavigationRailThemeData(
      backgroundColor: isLight ? Colors.white : const Color(0xFF0E0E13),
      indicatorColor: s.accent.withOpacity(0.25),
    ),
    sliderTheme: SliderThemeData(
      trackHeight: 6,
      activeTrackColor: s.accent,
      inactiveTrackColor: isLight
          ? const Color(0xFFDDD9EA)
          : VibeColors.outlineVariant.withOpacity(0.6),
      thumbColor: VibeColors.cyan,
      overlayColor: VibeColors.cyan.withOpacity(0.15),
    ),
    pageTransitionsTheme: s.performanceMode
        ? const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: _NoTransitionBuilder(),
              TargetPlatform.windows: _NoTransitionBuilder(),
            },
          )
        : null,
  );
}

class _NoTransitionBuilder extends PageTransitionsBuilder {
  const _NoTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    return child;
  }
}
