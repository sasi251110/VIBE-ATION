import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../effects/effects_screen.dart';
import '../home/home_screen.dart';
import '../library/library_controller.dart';
import '../library/library_screen.dart';
import '../search/search_screen.dart';
import '../settings/settings_screen.dart';
import 'mini_player.dart';

class _Destination {
  const _Destination(this.label, this.icon, this.selectedIcon);

  final String label;
  final IconData icon;
  final IconData selectedIcon;
}

const _destinations = <_Destination>[
  _Destination('Home', Icons.home_outlined, Icons.home),
  _Destination('Search', Icons.search, Icons.search),
  _Destination('Library', Icons.library_music_outlined, Icons.library_music),
  _Destination('Equalizer', Icons.equalizer_outlined, Icons.equalizer),
  _Destination('Settings', Icons.tune_outlined, Icons.tune),
];

/// Width at which the layout switches from bottom bar to side rail.
const double kWideLayoutBreakpoint = 800;

class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    // Read tags/artwork for any tracks that have not been read yet.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(libraryControllerProvider.notifier).enrichTags();
    });
  }

  // Pages are built on demand so audio is only touched when needed.
  Widget _page() {
    switch (_index) {
      case 0:
        return HomeScreen(onSeeAll: () => setState(() => _index = 2));
      case 1:
        return const SearchScreen();
      case 2:
        return const LibraryScreen();
      case 3:
        return const EffectsScreen();
      default:
        return const SettingsScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= kWideLayoutBreakpoint;
    final body = SafeArea(
      child: Column(
        children: [
          Expanded(child: _page()),
          const MiniPlayer(),
        ],
      ),
    );

    if (wide) {
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              selectedIndex: _index,
              labelType: NavigationRailLabelType.all,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: [
                for (final d in _destinations)
                  NavigationRailDestination(
                    icon: Icon(d.icon),
                    selectedIcon: Icon(d.selectedIcon),
                    label: Text(d.label),
                  ),
              ],
            ),
            Expanded(child: body),
          ],
        ),
      );
    }

    return Scaffold(
      body: body,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          for (final d in _destinations)
            NavigationDestination(
              icon: Icon(d.icon),
              selectedIcon: Icon(d.selectedIcon),
              label: d.label,
            ),
        ],
      ),
    );
  }
}
