import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio/just_audio.dart';

import '../../audio/player_service.dart';
import '../../core/theme/vibe_colors.dart';
import '../../widgets/track_art.dart';
import '../library/library_controller.dart';
import '../player/player_screen.dart';

class MiniPlayer extends ConsumerWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final np = ref.watch(nowPlayingProvider).valueOrNull;
    if (np == null) return const SizedBox.shrink();
    final svc = ref.watch(playerServiceProvider);
    final lib = ref.watch(libraryControllerProvider);
    final fav = lib.favorites.contains(np.id);

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
      child: Material(
        color: vibeCard(context),
        borderRadius: BorderRadius.circular(22),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              fullscreenDialog: true,
              builder: (_) => const PlayerScreen(),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              StreamBuilder<Duration>(
                stream: svc.player.positionStream,
                builder: (context, snap) {
                  final total = svc.player.duration?.inMilliseconds ?? 0;
                  final pos = snap.data?.inMilliseconds ?? 0;
                  return LinearProgressIndicator(
                    value: total > 0 ? (pos / total).clamp(0.0, 1.0) : 0,
                    minHeight: 3,
                    backgroundColor: Colors.transparent,
                    color: VibeColors.cyan,
                  );
                },
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 4, 6),
                child: Row(
                  children: [
                    TrackArt(
                      seed: np.title,
                      artPath: np.artUri?.toFilePath(),
                      size: 44,
                      radius: 12,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            np.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            np.artist ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Favorite',
                      icon: Icon(
                        fav ? Icons.favorite : Icons.favorite_border,
                        color: fav ? VibeColors.pink : null,
                      ),
                      onPressed: () => ref
                          .read(libraryControllerProvider.notifier)
                          .toggleFavorite(np.id),
                    ),
                    StreamBuilder<PlayerState>(
                      stream: svc.player.playerStateStream,
                      builder: (context, s) {
                        final playing = s.data?.playing ?? false;
                        return IconButton.filled(
                          style: IconButton.styleFrom(
                            backgroundColor: VibeColors.violet,
                            foregroundColor: const Color(0xFF1B0050),
                          ),
                          icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                          tooltip: playing ? 'Pause' : 'Play',
                          onPressed: svc.togglePlay,
                        );
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.skip_next),
                      tooltip: 'Next',
                      onPressed: svc.next,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
