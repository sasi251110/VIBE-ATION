import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../audio/player_service.dart';
import '../../core/models/track.dart';
import '../../core/theme/vibe_colors.dart';
import '../../widgets/empty_library.dart';
import '../../widgets/track_art.dart';
import '../library/library_controller.dart';
import '../library/library_screen.dart';
import '../player/player_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key, required this.onSeeAll});

  final VoidCallback onSeeAll;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lib = ref.watch(libraryControllerProvider);
    final np = ref.watch(nowPlayingProvider).valueOrNull;
    final theme = Theme.of(context);

    if (lib.tracks.isEmpty) {
      return Column(
        children: [
          const _Header(subtitle: 'Offline'),
          const Expanded(child: EmptyLibrary()),
        ],
      );
    }

    final recents = lib.resolve(lib.recents).take(4).toList();
    final current =
        np != null ? lib.byId(np.id) : (recents.isEmpty ? null : recents.first);
    final songs = lib.tracks.take(30).toList();

    return ListView(
      padding: const EdgeInsets.only(bottom: 16),
      children: [
        _Header(subtitle: 'Offline \u2022 ${lib.tracks.length} local files'),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Text(
            'Your Music, Your Vibe',
            style: theme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (current != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _ContinueCard(track: current, playing: np != null),
          ),
        if (recents.isNotEmpty) ...[
          const _SectionTitle(icon: Icons.history, title: 'Recently Played'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.82,
              children: [
                for (var i = 0; i < recents.length; i++)
                  _RecentCard(
                    track: recents[i],
                    onTap: () => playFrom(context, ref, recents, i),
                  ),
              ],
            ),
          ),
        ],
        _SectionTitle(
          icon: Icons.queue_music,
          title: 'All Songs',
          trailing: TextButton.icon(
            onPressed: () {
              final list = [...lib.tracks]..shuffle();
              playFrom(context, ref, list, 0);
            },
            icon: const Icon(Icons.shuffle, size: 18),
            label: const Text('Shuffle'),
          ),
        ),
        for (var i = 0; i < songs.length; i++)
          ListTile(
            leading: TrackArt(seed: songs[i].title, artPath: songs[i].artPath, size: 48),
            title: Text(
              songs[i].title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: np?.id == songs[i].id
                  ? const TextStyle(color: VibeColors.lavender)
                  : null,
            ),
            subtitle: Text(
              songs[i].subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            onTap: () => playFrom(context, ref, lib.tracks, i),
            trailing: IconButton(
              tooltip: 'Favorite',
              icon: Icon(
                lib.favorites.contains(songs[i].id)
                    ? Icons.favorite
                    : Icons.favorite_border,
                color: lib.favorites.contains(songs[i].id)
                    ? VibeColors.pink
                    : null,
              ),
              onPressed: () => ref
                  .read(libraryControllerProvider.notifier)
                  .toggleFavorite(songs[i].id),
            ),
          ),
        if (lib.tracks.length > songs.length)
          Center(
            child: TextButton(
              onPressed: onSeeAll,
              child: Text('See all ${lib.tracks.length} in Library'),
            ),
          ),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.subtitle});

  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        children: [
          Image.asset(
            'assets/images/logo.png',
            width: 40,
            height: 40,
            errorBuilder: (_, __, ___) => const Icon(Icons.music_note),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ShaderMask(
                shaderCallback: (r) => const LinearGradient(
                  colors: [VibeColors.lavender, VibeColors.cyan],
                ).createShader(r),
                child: const Text(
                  'VIBE-ATION',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: Colors.white,
                  ),
                ),
              ),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 12, color: VibeColors.cyan),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.icon, required this.title, this.trailing});

  final IconData icon;
  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 8, 8),
      child: Row(
        children: [
          Icon(icon, color: VibeColors.cyan),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class _ContinueCard extends ConsumerWidget {
  const _ContinueCard({required this.track, required this.playing});

  final Track track;
  final bool playing;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lib = ref.watch(libraryControllerProvider);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: vibeCard(context),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: VibeColors.outlineVariant.withOpacity(0.5),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              TrackArt(seed: track.title, artPath: track.artPath, size: 84, radius: 16),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'CONTINUE LISTENING',
                      style: TextStyle(
                        fontSize: 11,
                        letterSpacing: 1.5,
                        color: VibeColors.cyan,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      track.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    Text(
                      track.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [VibeColors.violet, VibeColors.cyan],
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: TextButton.icon(
                    style: TextButton.styleFrom(
                      foregroundColor: const Color(0xFF1B0050),
                      minimumSize: const Size.fromHeight(52),
                    ),
                    onPressed: () {
                      if (playing) {
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            fullscreenDialog: true,
                            builder: (_) => const PlayerScreen(),
                          ),
                        );
                      } else {
                        final i = lib.tracks.indexWhere((t) => t.id == track.id);
                        playFrom(context, ref, lib.tracks, i < 0 ? 0 : i);
                      }
                    },
                    icon: const Icon(Icons.play_arrow),
                    label: Text(
                      playing ? 'Open Player' : 'Resume Playback',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RecentCard extends StatelessWidget {
  const _RecentCard({required this.track, required this.onTap});

  final Track track;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: vibeCard(context),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) => TrackArt(
                  seed: track.title,
                  size: c.biggest.shortestSide,
                  radius: 14,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              track.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            Text(
              track.subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
