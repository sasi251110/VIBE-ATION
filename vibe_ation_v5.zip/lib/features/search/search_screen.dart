import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vibe_colors.dart';
import '../../widgets/track_art.dart';
import '../library/library_controller.dart';
import '../library/library_screen.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final lib = ref.watch(libraryControllerProvider);
    final q = _q.trim().toLowerCase();
    final results = q.isEmpty
        ? const []
        : lib.tracks
            .where(
              (t) =>
                  t.title.toLowerCase().contains(q) ||
                  t.artist.toLowerCase().contains(q) ||
                  (t.album ?? '').toLowerCase().contains(q) ||
                  t.fileName.toLowerCase().contains(q),
            )
            .toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'Search songs, artists, files',
              filled: true,
              fillColor: vibeCardHigh(context),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: BorderSide.none,
              ),
            ),
            onChanged: (v) => setState(() => _q = v),
          ),
        ),
        Expanded(
          child: q.isEmpty
              ? const Center(child: Text('Type to search your library'))
              : results.isEmpty
                  ? const Center(child: Text('No results'))
                  : ListView.builder(
                      itemCount: results.length,
                      itemBuilder: (context, i) => ListTile(
                        leading: TrackArt(seed: results[i].title, artPath: results[i].artPath, size: 48),
                        title: Text(
                          results[i].title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(
                          results[i].subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        onTap: () =>
                            playFrom(context, ref, results.cast(), i),
                      ),
                    ),
        ),
      ],
    );
  }
}
