import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio/just_audio.dart';

import '../../audio/player_service.dart';
import '../../core/theme/vibe_colors.dart';
import '../../widgets/prompt.dart';
import 'effects_controller.dart';
import 'effects_state.dart';

class EffectsScreen extends ConsumerWidget {
  const EffectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fx = ref.watch(effectsControllerProvider);
    final ctrl = ref.read(effectsControllerProvider.notifier);
    final np = ref.watch(nowPlayingProvider).valueOrNull;
    final theme = Theme.of(context);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Icon(Icons.graphic_eq, color: VibeColors.cyan),
            const SizedBox(width: 8),
            Text(
              'Equalizer',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _Panel(
          child: SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text(
              'MASTER EQ',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              np == null
                  ? 'Play a song to enable'
                  : (fx.eqEnabled ? 'Active' : 'Bypassed'),
              style: const TextStyle(color: VibeColors.cyan),
            ),
            value: fx.eqEnabled,
            onChanged: np == null ? null : ctrl.setEqEnabled,
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'SOUND SIGNATURE PRESETS',
          style: TextStyle(
            fontSize: 12,
            letterSpacing: 1.5,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (final name in [...kEqPresets.keys, ...fx.customPresets.keys])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(name),
                    selected: fx.eqEnabled && fx.presetName == name,
                    onSelected: (_) => ctrl.applyPreset(name),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        _Panel(
          child: np == null
              ? const Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('Play a song to adjust the equalizer bands.'),
                )
              : _EqBands(fx: fx),
        ),
        const SizedBox(height: 16),
        _Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Slowed Playback',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              _LabelRow('Playback speed', '${fx.speed.toStringAsFixed(2)}x'),
              Slider(
                value: fx.speed,
                min: 0.5,
                max: 2.0,
                divisions: 30,
                onChanged: ctrl.setSpeed,
              ),
              _LabelRow('Pitch', '${fx.pitch.toStringAsFixed(2)}x'),
              Slider(
                value: fx.pitch,
                min: 0.5,
                max: 2.0,
                divisions: 30,
                onChanged: ctrl.setPitch,
              ),
              Wrap(
                spacing: 8,
                children: [
                  OutlinedButton(
                    onPressed: ctrl.applySlowed,
                    child: const Text('Slowed (0.85x)'),
                  ),
                  OutlinedButton(
                    onPressed: () async {
                      await ctrl.setSpeed(1.0);
                      await ctrl.setPitch(1.0);
                    },
                    child: const Text('Normal'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Speed and pitch change together. Reverb is not implemented yet.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Volume Booster',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              _LabelRow('Level', '${fx.boostPercent.round()}%'),
              Slider(
                value: fx.boostPercent,
                min: 100,
                max: 300,
                divisions: 40,
                onChanged: ctrl.setBoost,
              ),
              Row(
                children: [
                  Icon(
                    Icons.shield_outlined,
                    color: fx.boostPercent > 150
                        ? theme.colorScheme.error
                        : VibeColors.cyan,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      fx.boostPercent > 100
                          ? 'Above 100% can distort and be very loud. 300% is about +9.5 dB. Android\'s LoudnessEnhancer is not a hard limiter.'
                          : 'Normal level.',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _Panel(
          child: Row(
            children: [
              const Icon(Icons.hourglass_empty, color: VibeColors.outline),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Coming soon: reverb, 3D spatial audio, bass reflex, treble clarity, AI equalizer.',
                  style: TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: ctrl.resetAll,
                icon: const Icon(Icons.restore),
                label: const Text('Reset to Flat'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: vibeCard(context),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: VibeColors.outlineVariant.withOpacity(0.4)),
      ),
      child: child,
    );
  }
}

class _LabelRow extends StatelessWidget {
  const _LabelRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(
          value,
          style: const TextStyle(
            color: VibeColors.cyan,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _EqBands extends ConsumerWidget {
  const _EqBands({required this.fx});

  final EffectsState fx;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final svc = ref.watch(playerServiceProvider);
    final ctrl = ref.read(effectsControllerProvider.notifier);
    return FutureBuilder<AndroidEqualizerParameters>(
      future: svc.eq.parameters,
      builder: (context, snap) {
        final params = snap.data;
        if (params == null) return const Text('Equalizer starting...');
        final n = params.bands.length;
        final gains = resampleCurve(fx.eqGains, n);
        return Column(
          children: [
            SizedBox(
              height: 230,
              child: Row(
                children: [
                  for (var i = 0; i < n; i++)
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            gains[i].toStringAsFixed(1),
                            style: const TextStyle(
                              fontSize: 11,
                              color: VibeColors.cyan,
                            ),
                          ),
                          Expanded(
                            child: RotatedBox(
                              quarterTurns: 3,
                              child: Slider(
                                value: gains[i]
                                    .clamp(params.minDecibels, params.maxDecibels)
                                    .toDouble(),
                                min: params.minDecibels,
                                max: params.maxDecibels,
                                onChanged: (v) => ctrl.setEqGain(i, n, v),
                              ),
                            ),
                          ),
                          Text(
                            _freq(params.bands[i].centerFrequency),
                            style: const TextStyle(fontSize: 10),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                icon: const Icon(Icons.save),
                label: const Text('Save custom profile'),
                onPressed: () async {
                  final name = await promptText(context, title: 'Preset name');
                  if (name != null) await ctrl.saveCustomPreset(name, n);
                },
              ),
            ),
          ],
        );
      },
    );
  }

  String _freq(double hz) =>
      hz >= 1000 ? '${(hz / 1000).toStringAsFixed(1)}k' : '${hz.round()}';
}
