import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

/// Audio file extensions the scanner will list. Whether a format actually
/// plays depends on Android's decoders (e.g. WMA/APE often will not).
const Set<String> kAudioExtensions = {
  'mp3',
  'm4a',
  'aac',
  'ogg',
  'oga',
  'opus',
  'wav',
  'flac',
  'aif',
  'aiff',
  'wma',
  'ape',
  'amr',
  'mka',
  '3gp',
  'mid',
  'midi',
};

/// Files smaller than this are skipped (ringtones, UI sounds).
const int kMinAudioBytes = 64 * 1024;

bool isAudioPath(String path) {
  final ext = p.extension(path).toLowerCase();
  return ext.length > 1 && kAudioExtensions.contains(ext.substring(1));
}

/// Recursively lists audio files under [roots]. Unreadable folders are
/// skipped instead of aborting the scan. Hidden folders and "Android" are
/// skipped. Must be a top-level function so it can run in an isolate.
List<String> scanDirectories(List<String> roots) {
  final found = <String>{};
  final seen = <String>{};
  final stack = <String>[...roots];
  while (stack.isNotEmpty) {
    final dir = stack.removeLast();
    if (!seen.add(dir)) continue;
    List<FileSystemEntity> entries;
    try {
      entries = Directory(dir).listSync(followLinks: false);
    } catch (_) {
      continue;
    }
    for (final e in entries) {
      final name = p.basename(e.path);
      if (e is Directory) {
        if (name.startsWith('.') || name == 'Android') continue;
        stack.add(e.path);
      } else if (e is File && isAudioPath(e.path)) {
        try {
          if (e.lengthSync() >= kMinAudioBytes) found.add(e.path);
        } catch (_) {}
      }
    }
  }
  final out = found.toList()
    ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
  return out;
}

Future<List<String>> scanInBackground(List<String> roots) =>
    compute(scanDirectories, roots);

/// Internal storage plus any SD card / USB volumes mounted under /storage.
List<String> defaultScanRoots() {
  final roots = <String>['/storage/emulated/0'];
  try {
    for (final e in Directory('/storage').listSync()) {
      final n = p.basename(e.path);
      if (e is Directory && n != 'emulated' && n != 'self') roots.add(e.path);
    }
  } catch (_) {}
  return roots;
}
