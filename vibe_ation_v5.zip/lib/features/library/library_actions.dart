import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';

import 'library_controller.dart';
import 'scanner.dart';

final scanningProvider = StateProvider<bool>((ref) => false);

Future<bool> _ensureAudioPermission(ScaffoldMessengerState messenger) async {
  final res = await [Permission.audio, Permission.storage].request();
  if (res.values.any((s) => s.isGranted)) return true;
  messenger.showSnackBar(
    SnackBar(
      content: const Text('Allow access to audio files to scan your device.'),
      action: SnackBarAction(
        label: 'Settings',
        onPressed: () => openAppSettings(),
      ),
    ),
  );
  return false;
}

Future<void> scanRoots(BuildContext context, List<String> roots) async {
  final container = ProviderScope.containerOf(context, listen: false);
  final messenger = ScaffoldMessenger.of(context);
  if (container.read(scanningProvider)) return;
  if (!await _ensureAudioPermission(messenger)) return;
  container.read(scanningProvider.notifier).state = true;
  try {
    final paths = await scanInBackground(roots);
    final added = await container
        .read(libraryControllerProvider.notifier)
        .addPaths(paths);
    messenger.showSnackBar(
      SnackBar(content: Text('Found ${paths.length} audio files, $added new')),
    );
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Scan failed: $e')));
  } finally {
    container.read(scanningProvider.notifier).state = false;
  }
}

Future<void> scanDevice(BuildContext context) =>
    scanRoots(context, defaultScanRoots());

Future<void> addFolder(BuildContext context) async {
  final messenger = ScaffoldMessenger.of(context);
  try {
    final dir = await FilePicker.platform.getDirectoryPath();
    if (dir == null || !context.mounted) return;
    await scanRoots(context, [dir]);
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Could not open folder: $e')));
  }
}

Future<void> addFiles(BuildContext context) async {
  final container = ProviderScope.containerOf(context, listen: false);
  final messenger = ScaffoldMessenger.of(context);
  try {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: true,
    );
    if (res == null) return;
    final paths = res.paths.whereType<String>().toList();
    final added = await container
        .read(libraryControllerProvider.notifier)
        .addPaths(paths);
    messenger.showSnackBar(SnackBar(content: Text('Added $added track(s)')));
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Could not add files: $e')));
  }
}
