import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../features/library/library_actions.dart';

class EmptyLibrary extends ConsumerWidget {
  const EmptyLibrary({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scanning = ref.watch(scanningProvider);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 120,
              height: 120,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.library_music, size: 64),
            ),
            const SizedBox(height: 12),
            const Text('Your library is empty'),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: scanning ? null : () => scanDevice(context),
              icon: const Icon(Icons.search),
              label: Text(scanning ? 'Scanning...' : 'Scan device for all audio'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: scanning ? null : () => addFolder(context),
              icon: const Icon(Icons.folder_open),
              label: const Text('Add a folder'),
            ),
            TextButton(
              onPressed: scanning ? null : () => addFiles(context),
              child: const Text('Pick individual files'),
            ),
          ],
        ),
      ),
    );
  }
}
