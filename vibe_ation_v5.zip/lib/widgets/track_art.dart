import 'dart:io';

import 'package:flutter/material.dart';

/// Album artwork: the embedded cover when available, otherwise a gradient
/// picked from the track name with a music note.
class TrackArt extends StatelessWidget {
  const TrackArt({
    super.key,
    required this.seed,
    this.artPath,
    this.size = 56,
    this.radius = 12,
  });

  final String seed;
  final String? artPath;
  final double size;
  final double radius;

  static const _pairs = <List<Color>>[
    [Color(0xFF6D3BD7), Color(0xFF00CBE6)],
    [Color(0xFFF751A1), Color(0xFF6D3BD7)],
    [Color(0xFF00CBE6), Color(0xFF3C0091)],
    [Color(0xFFA078FF), Color(0xFFF751A1)],
    [Color(0xFF2FD9F4), Color(0xFFA078FF)],
  ];

  Widget _fallback() {
    final pair = _pairs[seed.hashCode.abs() % _pairs.length];
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          colors: pair,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Icon(Icons.music_note, size: size * 0.45, color: Colors.white70),
    );
  }

  @override
  Widget build(BuildContext context) {
    final path = artPath;
    if (path == null) return _fallback();
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Image.file(
        File(path),
        width: size,
        height: size,
        fit: BoxFit.cover,
        cacheWidth: (size * 2).round(),
        errorBuilder: (_, __, ___) => _fallback(),
      ),
    );
  }
}
