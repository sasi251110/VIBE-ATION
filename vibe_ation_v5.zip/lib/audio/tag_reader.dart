import 'package:flutter/services.dart';

import '../core/models/track.dart';

/// Reads tags and embedded artwork through a small native Android channel
/// (see MainActivity.kt). Returns null if the file cannot be read.
class TagReader {
  const TagReader._();

  static const MethodChannel _channel = MethodChannel('com.vibeation/tags');

  static Future<TrackTags?> read(String path) async {
    try {
      final r = await _channel.invokeMapMethod<String, dynamic>('read', {
        'path': path,
      });
      if (r == null) return null;
      return TrackTags.fromMap(r);
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }
}
