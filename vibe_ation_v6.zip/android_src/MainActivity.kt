package com.vibeation.vibe_ation

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class MainActivity : AudioServiceActivity() {
    private val executor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bass: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var visualizer: Visualizer? = null
    private var vizSink: EventChannel.EventSink? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "com.vibeation/tags").setMethodCallHandler { call, result ->
            when (call.method) {
                "read" -> {
                    val path = call.argument<String>("path")
                    if (path == null) {
                        result.error("ARG", "path missing", null)
                    } else {
                        executor.execute {
                            val out = readTags(path)
                            mainHandler.post { result.success(out) }
                        }
                    }
                }
                "analyze" -> {
                    val path = call.argument<String>("path")
                    if (path == null) {
                        result.error("ARG", "path missing", null)
                    } else {
                        executor.execute {
                            val out = analyze(path)
                            mainHandler.post { result.success(out) }
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }

        EventChannel(messenger, "com.vibeation/viz").setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    vizSink = events
                }

                override fun onCancel(arguments: Any?) {
                    vizSink = null
                }
            }
        )

        MethodChannel(messenger, "com.vibeation/fx").setMethodCallHandler { call, result ->
            when (call.method) {
                "attach" -> {
                    val sid = call.argument<Int>("session") ?: 0
                    result.success(attachEffects(sid))
                }
                "setBass" -> {
                    val s = call.argument<Int>("strength") ?: 0
                    try {
                        bass?.setStrength(s.coerceIn(0, 1000).toShort())
                        bass?.setEnabled(s > 0)
                    } catch (_: Exception) {
                    }
                    result.success(null)
                }
                "setSpatial" -> {
                    val s = call.argument<Int>("strength") ?: 0
                    try {
                        virtualizer?.setStrength(s.coerceIn(0, 1000).toShort())
                        virtualizer?.setEnabled(s > 0)
                    } catch (_: Exception) {
                    }
                    result.success(null)
                }
                "startViz" -> {
                    val sid = call.argument<Int>("session") ?: 0
                    result.success(startVisualizer(sid))
                }
                "stopViz" -> {
                    stopVisualizer()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onDestroy() {
        stopVisualizer()
        releaseEffects()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- effects

    private fun releaseEffects() {
        try { bass?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        bass = null
        virtualizer = null
    }

    private fun attachEffects(sessionId: Int): HashMap<String, Any?> {
        releaseEffects()
        val out = HashMap<String, Any?>()
        try {
            val b = BassBoost(0, sessionId)
            bass = b
            out["bass"] = b.strengthSupported
        } catch (e: Exception) {
            out["bass"] = false
        }
        try {
            val v = Virtualizer(0, sessionId)
            virtualizer = v
            out["virtualizer"] = v.strengthSupported
        } catch (e: Exception) {
            out["virtualizer"] = false
        }
        return out
    }

    // -------------------------------------------------------------- visualizer

    private fun stopVisualizer() {
        try {
            visualizer?.setEnabled(false)
            visualizer?.release()
        } catch (_: Exception) {
        }
        visualizer = null
    }

    /** Returns null on success, or an error message. */
    private fun startVisualizer(sessionId: Int): String? {
        stopVisualizer()
        return try {
            val v = Visualizer(sessionId)
            val range = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(min(1024, range[1]))
            v.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        vis: Visualizer?, waveform: ByteArray?, samplingRate: Int
                    ) {
                        if (waveform == null) return
                        val n = 64
                        val data = DoubleArray(n)
                        val step = max(1, waveform.size / n)
                        for (i in 0 until n) {
                            val idx = min(waveform.size - 1, i * step)
                            data[i] = ((waveform[idx].toInt() and 0xFF) - 128) / 128.0
                        }
                        mainHandler.post { vizSink?.success(hashMapOf("wave" to data)) }
                    }

                    override fun onFftDataCapture(
                        vis: Visualizer?, fft: ByteArray?, samplingRate: Int
                    ) {
                        if (fft == null) return
                        val half = fft.size / 2
                        val bands = 32
                        val out = DoubleArray(bands)
                        for (b in 0 until bands) {
                            val lo = max(1, (half - 1).toDouble().pow(b.toDouble() / bands).toInt())
                            val hi = max(lo + 1, (half - 1).toDouble().pow((b + 1).toDouble() / bands).toInt())
                            var peak = 0.0
                            for (k in lo until min(hi, half)) {
                                val re = fft[2 * k].toDouble()
                                val im = fft[2 * k + 1].toDouble()
                                peak = max(peak, hypot(re, im))
                            }
                            out[b] = min(1.0, (peak / 128.0).pow(0.6))
                        }
                        mainHandler.post { vizSink?.success(hashMapOf("fft" to out)) }
                    }
                },
                Visualizer.getMaxCaptureRate(),
                true,
                true
            )
            v.setEnabled(true)
            visualizer = v
            null
        } catch (e: Exception) {
            e.message ?: e.toString()
        }
    }

    // ------------------------------------------------------------------- tags

    private fun readTags(path: String): HashMap<String, Any?> {
        val map = HashMap<String, Any?>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            map["title"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            map["artist"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            map["album"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            map["albumArtist"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            map["genre"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            map["year"] = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
            map["durationMs"] =
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            val pic = r.embeddedPicture
            if (pic != null) {
                val dir = File(cacheDir, "art")
                dir.mkdirs()
                val f = File(dir, "${path.hashCode()}_${File(path).length()}.jpg")
                if (!f.exists()) f.writeBytes(pic)
                map["artPath"] = f.absolutePath
            }
        } catch (e: Exception) {
            map["error"] = e.message
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        return map
    }

    // --------------------------------------------------------------- analysis

    private val bandCenters =
        doubleArrayOf(31.25, 62.5, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)

    /**
     * Decodes up to ~15 s from the middle of the file and measures the average
     * energy in 10 octave bands plus RMS and peak level. Everything runs locally.
     */
    private fun analyze(path: String): HashMap<String, Any?> {
        val out = HashMap<String, Any?>()
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(path)
            var trackIdx = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIdx = i
                    format = f
                    break
                }
            }
            if (trackIdx < 0 || format == null) {
                out["error"] = "no audio track"
                return out
            }
            extractor.selectTrack(trackIdx)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val durationUs =
                if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durationUs > 60_000_000L) {
                extractor.seekTo(durationUs / 2 - 7_500_000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            }

            val maxSamples = sampleRate * 15
            val pcm = FloatArray(maxSamples)
            var count = 0

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            while (!outputDone && count < maxSamples && guard < 20000) {
                guard++
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                if (outIdx >= 0) {
                    val ob = codec.getOutputBuffer(outIdx)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val shorts = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val total = shorts.remaining()
                        val frames = total / max(1, channels)
                        for (fr in 0 until frames) {
                            if (count >= maxSamples) break
                            var sum = 0f
                            for (c in 0 until channels) sum += shorts.get(fr * channels + c) / 32768f
                            pcm[count++] = sum / channels
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }

            val n = 4096
            if (count < n * 4) {
                out["error"] = "not enough audio decoded"
                return out
            }

            var sumSq = 0.0
            var peak = 0.0
            for (i in 0 until count) {
                val s = pcm[i].toDouble()
                sumSq += s * s
                peak = max(peak, abs(s))
            }
            val rms = Math.sqrt(sumSq / count)

            val window = DoubleArray(n) { 0.5 - 0.5 * Math.cos(2.0 * Math.PI * it / (n - 1)) }
            val binHz = sampleRate.toDouble() / n
            val bandPower = DoubleArray(bandCenters.size)
            val bandBins = IntArray(bandCenters.size)
            val lo = IntArray(bandCenters.size)
            val hi = IntArray(bandCenters.size)
            for (b in bandCenters.indices) {
                lo[b] = max(1, Math.ceil(bandCenters[b] / Math.sqrt(2.0) / binHz).toInt())
                hi[b] = min(n / 2 - 1, Math.floor(bandCenters[b] * Math.sqrt(2.0) / binHz).toInt())
            }
            var windows = 0
            val re = DoubleArray(n)
            val im = DoubleArray(n)
            var pos = 0
            while (pos + n <= count) {
                for (i in 0 until n) {
                    re[i] = pcm[pos + i] * window[i]
                    im[i] = 0.0
                }
                fftInPlace(re, im)
                for (b in bandCenters.indices) {
                    if (hi[b] < lo[b]) continue
                    var p = 0.0
                    for (k in lo[b]..hi[b]) p += (re[k] * re[k] + im[k] * im[k]) / (n.toDouble() * n)
                    bandPower[b] += p
                    bandBins[b] = hi[b] - lo[b] + 1
                }
                windows++
                pos += n
            }
            val bands = ArrayList<Double>()
            for (b in bandCenters.indices) {
                if (bandBins[b] == 0 || windows == 0) {
                    bands.add(-120.0)
                } else {
                    bands.add(10.0 * log10(bandPower[b] / windows + 1e-12))
                }
            }
            out["bandsDb"] = bands
            out["rmsDb"] = 20.0 * log10(rms + 1e-9)
            out["peakDb"] = 20.0 * log10(peak + 1e-9)
            out["seconds"] = count.toDouble() / sampleRate
        } catch (e: Exception) {
            out["error"] = e.message ?: e.toString()
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
        return out
    }

    private fun fftInPlace(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wlr = Math.cos(ang)
            val wli = Math.sin(ang)
            var i = 0
            while (i < n) {
                var wr = 1.0
                var wi = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = i + k + len / 2
                    val ur = re[a]; val ui = im[a]
                    val vr = re[b] * wr - im[b] * wi
                    val vi = re[b] * wi + im[b] * wr
                    re[a] = ur + vr; im[a] = ui + vi
                    re[b] = ur - vr; im[b] = ui - vi
                    val nwr = wr * wlr - wi * wli
                    wi = wr * wli + wi * wlr
                    wr = nwr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
