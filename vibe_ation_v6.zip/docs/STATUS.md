# Feature status (Android only)

Nothing here has been compiled or run by the author of this file. "Unit-tested" means tests were written, not that they have passed. Check CI.

## Implemented (written, unverified)
- Add audio files via picker, local library, search (title/artist/filename), sort, favorites, recents, playlists (all persisted in local preferences)
- Playback via just_audio: play/pause/seek/next/previous, queue (add/remove/reorder/clear/next-up), shuffle, repeat off/all/one, background playback + media notification (just_audio_background)
- Speed and pitch, "Slowed" preset, 5-band system equalizer with presets and custom presets, volume boost 100-300% (Android LoudnessEnhancer)
- Lyrics: paste/edit, import .lrc/.txt, synced highlight, sidecar .lrc discovery, font size
- Player layouts: vinyl (spin toggle), album, minimal; dark/AMOLED/light, accent color, performance mode

## NOT implemented
- Reading embedded tags/artwork; metadata editor (display-only or file)
- Reverb (so no "Slowed + Reverb"), bass/treble/balance/fades/compressor/crossfade/normalization
- Offline AI equalizer, audio-reactive visualizer, DJ mode, fullscreen visualizer
- SQLite (library uses SharedPreferences JSON), album search, signed release builds
- Windows (dropped by request)

## Added
- Scan whole device (internal + SD card) or a chosen folder for audio files (mp3, m4a, aac, ogg, opus, wav, flac, aiff, wma, ape, amr, mka, 3gp, midi). Runs in the background; skips hidden folders, Android/ and files under 64 KB. Listing a format does not guarantee Android can decode it.

## UI and metadata (latest)
- UI rebuilt from the Stitch design: splash, Home (continue listening, recently played, all songs), Search, Library, Now Playing (full-screen), Vinyl turntable with tonearm, Equalizer screen, mini-player
- Real tags and embedded album art read via a small native Android channel (MediaMetadataRetriever): title, artist, album, duration, cover. Shown in lists, mini-player, player, and the notification
- Not real yet, and shown as "coming soon" or omitted: audio-reactive spectrum/visualizer, reverb, spatial audio, bass/treble exciters, bit-depth/sample-rate badges, tube/crackle vinyl effects

## Latest additions (unverified on device; check CI and test on phone)
- Visualizer: real spectrum, waveform and circular views from Android's Visualizer API (needs microphone permission; nothing is recorded). Inline panel on Now Playing plus fullscreen mode, style and intensity controls. Disabled in performance mode. Beat-reactive effects not implemented.
- Bass Reflex Booster: Android BassBoost (strength depends on the phone; may be unsupported)
- 3D Spatial Audio: Android Virtualizer (often only audible on headphones; may be unsupported)
- Treble Clarity: lifts the top equalizer bands up to +6 dB (uses the system equalizer)
- AI Equalizer: decodes ~15 s of the song locally, measures 10 octave bands plus RMS/peak, and suggests EQ using a hand-tuned reference profile. Preview, before/after, apply, reset, save as preset. This is signal analysis with rules, NOT a trained ML model.
- Artist pages: tap the artist in Now Playing, the Artists tab, or "Go to artist" in a song menu. Credits like "A; B", "A / B", "A feat. B" are split
- Sorting: natural (2 before 10), case/accent-insensitive, ignores leading "The/A/An" and punctuation, missing values last, title/artist/album/duration/date added, either direction, remembered between launches

## Still not implemented
- Reverb ("Slowed + Reverb"), metadata editing, SQLite, signed release builds
