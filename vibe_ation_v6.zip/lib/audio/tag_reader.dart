import 'package:flutter/services.dart';

import '../core/models/track.dart';
import '../features/ai_eq/eq_recommender.dart';

/// Reads tags/artwork and runs offline audio analysis through a small native
/// Android channel (see MainActivity.kt).
class TagReader {
  const TagReader._();

  static const MethodChannel _channel = MethodChannel('com.vibeation/tags');

  static Future<TrackTags?> read(String path) async {
    try {
      final r = await _channel.invokeMapMethod<String, dynamic>('read', {
        'path': path,
      });
      if (r == null) return null;
      return TrackTags.fromMap(r);
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  /// Decodes part of the song locally and measures its frequency balance.
  /// Returns null if the file cannot be analysed.
  static Future<AudioAnalysis?> analyze(String path) async {
    try {
      final r = await _channel.invokeMapMethod<String, dynamic>('analyze', {
        'path': path,
      });
      if (r == null || r['error'] != null) return null;
      return AudioAnalysis.fromMap(r);
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }
}
