import 'package:flutter/services.dart';

/// Which Android audio effects this device actually supports.
class FxSupport {
  const FxSupport({this.known = false, this.bass = false, this.virtualizer = false});

  final bool known;
  final bool bass;
  final bool virtualizer;
}

/// Bridge to Android's BassBoost, Virtualizer and Visualizer (MainActivity.kt).
class NativeFx {
  const NativeFx._();

  static const MethodChannel _fx = MethodChannel('com.vibeation/fx');
  static const EventChannel _viz = EventChannel('com.vibeation/viz');

  static Future<FxSupport> attach(int sessionId) async {
    try {
      final r = await _fx.invokeMapMethod<String, dynamic>('attach', {
        'session': sessionId,
      });
      return FxSupport(
        known: true,
        bass: r?['bass'] == true,
        virtualizer: r?['virtualizer'] == true,
      );
    } on PlatformException {
      return const FxSupport(known: true);
    } on MissingPluginException {
      return const FxSupport();
    }
  }

  /// [percent] 0..100 maps to Android strength 0..1000.
  static Future<void> setBass(double percent) => _safe(
        'setBass',
        {'strength': (percent * 10).round()},
      );

  static Future<void> setSpatial(double percent) => _safe(
        'setSpatial',
        {'strength': (percent * 10).round()},
      );

  static Future<void> _safe(String method, Map<String, dynamic> args) async {
    try {
      await _fx.invokeMethod<void>(method, args);
    } on PlatformException {
      // Effect not supported on this device.
    } on MissingPluginException {
      // Not running on Android (tests).
    }
  }

  /// Returns null on success or an error message.
  static Future<String?> startVisualizer(int sessionId) async {
    try {
      return await _fx.invokeMethod<String>('startViz', {'session': sessionId});
    } on PlatformException catch (e) {
      return e.message ?? 'Visualizer failed';
    } on MissingPluginException {
      return 'Visualizer is only available on Android';
    }
  }

  static Future<void> stopVisualizer() => _safe('stopViz', {});

  /// Raw frames: maps with either 'fft' (32 values 0..1) or 'wave' (64 values -1..1).
  static Stream<Map<dynamic, dynamic>> get frames => _viz
      .receiveBroadcastStream()
      .where((e) => e is Map)
      .cast<Map<dynamic, dynamic>>();
}
