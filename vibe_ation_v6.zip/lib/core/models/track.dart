import 'package:path/path.dart' as p;

/// Tags read from the audio file itself (Android MediaMetadataRetriever).
class TrackTags {
  const TrackTags({
    this.title,
    this.artist,
    this.album,
    this.albumArtist,
    this.genre,
    this.year,
    this.durationMs,
    this.artPath,
  });

  factory TrackTags.fromMap(Map<dynamic, dynamic> m) {
    String? s(String k) {
      final v = m[k];
      if (v is! String) return null;
      final t = v.trim();
      return t.isEmpty ? null : t;
    }

    return TrackTags(
      title: s('title'),
      artist: s('artist'),
      album: s('album'),
      albumArtist: s('albumArtist'),
      genre: s('genre'),
      year: s('year'),
      durationMs: (m['durationMs'] as num?)?.toInt(),
      artPath: s('artPath'),
    );
  }

  final String? title;
  final String? artist;
  final String? album;
  final String? albumArtist;
  final String? genre;
  final String? year;
  final int? durationMs;
  final String? artPath;
}

class Track {
  const Track({
    required this.path,
    required this.title,
    this.artist = 'Unknown artist',
    this.album,
    this.durationMs,
    this.artPath,
    this.tagged = false,
    this.addedAt = 0,
  });

  /// Title comes from the filename until tags are read; "Artist - Title"
  /// names are split.
  factory Track.fromPath(String path, {int addedAt = 0}) {
    final base = p.basenameWithoutExtension(path);
    final i = base.indexOf(' - ');
    if (i > 0 && i < base.length - 3) {
      return Track(
        path: path,
        title: base.substring(i + 3).trim(),
        artist: base.substring(0, i).trim(),
        addedAt: addedAt,
      );
    }
    return Track(path: path, title: base, addedAt: addedAt);
  }

  factory Track.fromJson(Map<String, dynamic> j) => Track(
        path: j['path'] as String,
        title: j['title'] as String,
        artist: (j['artist'] as String?) ?? 'Unknown artist',
        album: j['album'] as String?,
        durationMs: (j['durationMs'] as num?)?.toInt(),
        artPath: j['artPath'] as String?,
        tagged: j['tagged'] as bool? ?? false,
        addedAt: (j['addedAt'] as num?)?.toInt() ?? 0,
      );

  final String path;
  final String title;
  final String artist;
  final String? album;
  final int? durationMs;
  final String? artPath;
  final bool tagged;

  /// When the track was added to the library (ms since epoch).
  final int addedAt;

  String get id => path;
  String get fileName => p.basename(path);

  /// "Artist - Album" line for lists.
  String get subtitle {
    final a = album;
    return (a == null || a.isEmpty) ? artist : '$artist \u2022 $a';
  }

  /// Returns a copy with tags applied (missing tags keep current values).
  /// Always marks the track as tagged so it is not read again.
  Track withTags(TrackTags? t) {
    if (t == null) return copyWith(tagged: true);
    return Track(
      path: path,
      title: t.title ?? title,
      artist: t.artist ?? t.albumArtist ?? artist,
      album: t.album ?? album,
      durationMs: t.durationMs ?? durationMs,
      artPath: t.artPath ?? artPath,
      tagged: true,
      addedAt: addedAt,
    );
  }

  Track copyWith({bool? tagged}) => Track(
        path: path,
        title: title,
        artist: artist,
        album: album,
        durationMs: durationMs,
        artPath: artPath,
        tagged: tagged ?? this.tagged,
        addedAt: addedAt,
      );

  Map<String, dynamic> toJson() => {
        'path': path,
        'title': title,
        'artist': artist,
        'album': album,
        'durationMs': durationMs,
        'artPath': artPath,
        'tagged': tagged,
        'addedAt': addedAt,
      };
}
