import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../audio/native_fx.dart';
import '../../audio/player_service.dart';
import '../../core/theme/theme_controller.dart';

enum VizStyle { bars, wave, circle }

class VizPrefs {
  const VizPrefs({this.style = VizStyle.bars, this.intensity = 1.0});

  final VizStyle style;
  final double intensity;
}

final vizPrefsProvider =
    NotifierProvider<VizPrefsController, VizPrefs>(VizPrefsController.new);

class VizPrefsController extends Notifier<VizPrefs> {
  static const _kStyle = 'viz.style';
  static const _kIntensity = 'viz.intensity';

  @override
  VizPrefs build() {
    final prefs = ref.watch(sharedPreferencesProvider);
    return VizPrefs(
      style: VizStyle.values.firstWhere(
        (s) => s.name == prefs.getString(_kStyle),
        orElse: () => VizStyle.bars,
      ),
      intensity: prefs.getDouble(_kIntensity) ?? 1.0,
    );
  }

  Future<void> setStyle(VizStyle s) async {
    state = VizPrefs(style: s, intensity: state.intensity);
    await ref.read(sharedPreferencesProvider).setString(_kStyle, s.name);
  }

  Future<void> setIntensity(double v) async {
    state = VizPrefs(style: state.style, intensity: v);
    await ref.read(sharedPreferencesProvider).setDouble(_kIntensity, v);
  }
}

final visualizerServiceProvider = Provider<VisualizerService>(
  (ref) => VisualizerService(ref),
);

/// Starts/stops Android's Visualizer on the player's audio session. Several
/// screens can use it at once; it stops when the last one releases it.
class VisualizerService {
  VisualizerService(this._ref);

  final Ref _ref;
  int _users = 0;

  /// Returns null on success, or a message explaining what is missing.
  Future<String?> acquire() async {
    // Android requires the microphone permission for its Visualizer API.
    // Nothing is recorded; only the app's own audio output is analysed.
    final mic = await Permission.microphone.request();
    if (!mic.isGranted) {
      return 'Android needs the microphone permission to read the audio '
          'spectrum. Nothing is recorded.';
    }
    final id = _ref.read(playerServiceProvider).player.androidAudioSessionId;
    if (id == null) return 'Start playing a song first.';
    if (_users == 0) {
      final err = await NativeFx.startVisualizer(id);
      if (err != null) return err;
    }
    _users++;
    return null;
  }

  Future<void> release() async {
    if (_users == 0) return;
    _users--;
    if (_users == 0) await NativeFx.stopVisualizer();
  }
}
