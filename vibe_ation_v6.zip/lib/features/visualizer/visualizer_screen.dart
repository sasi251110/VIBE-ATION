import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../audio/player_service.dart';
import '../../core/theme/vibe_colors.dart';
import 'spectrum_view.dart';
import 'visualizer_service.dart';

class VisualizerScreen extends ConsumerStatefulWidget {
  const VisualizerScreen({super.key});

  @override
  ConsumerState<VisualizerScreen> createState() => _VisualizerScreenState();
}

class _VisualizerScreenState extends ConsumerState<VisualizerScreen> {
  late final VisualizerService _viz;
  bool _acquired = false;
  String? _error;
  bool _showArt = true;

  @override
  void initState() {
    super.initState();
    _viz = ref.read(visualizerServiceProvider);
    _viz.acquire().then((err) {
      if (!mounted) {
        if (err == null) _viz.release();
        return;
      }
      setState(() {
        _acquired = err == null;
        _error = err;
      });
    });
  }

  @override
  void dispose() {
    if (_acquired) _viz.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prefs = ref.watch(vizPrefsProvider);
    final ctrl = ref.read(vizPrefsProvider.notifier);
    final np = ref.watch(nowPlayingProvider).valueOrNull;
    final art = np?.artUri?.toFilePath();

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  tooltip: 'Close',
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.of(context).maybePop(),
                ),
                Expanded(
                  child: Text(
                    np?.title ?? 'Visualizer',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(width: 48),
              ],
            ),
            Expanded(
              child: _error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(_error!, textAlign: TextAlign.center),
                      ),
                    )
                  : Stack(
                      alignment: Alignment.center,
                      children: [
                        if (_showArt && art != null)
                          Opacity(
                            opacity: 0.35,
                            child: ClipOval(
                              child: Image.file(
                                File(art),
                                width: 220,
                                height: 220,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const SizedBox(),
                              ),
                            ),
                          ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: LayoutBuilder(
                            builder: (context, c) => SpectrumView(
                              style: prefs.style,
                              intensity: prefs.intensity,
                              height: c.maxHeight,
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Column(
                children: [
                  Wrap(
                    spacing: 8,
                    children: [
                      for (final s in VizStyle.values)
                        ChoiceChip(
                          label: Text(switch (s) {
                            VizStyle.bars => 'Spectrum',
                            VizStyle.wave => 'Waveform',
                            VizStyle.circle => 'Circular',
                          }),
                          selected: prefs.style == s,
                          onSelected: (_) => ctrl.setStyle(s),
                        ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text('Intensity'),
                      Expanded(
                        child: Slider(
                          value: prefs.intensity,
                          min: 0.3,
                          max: 2.0,
                          onChanged: ctrl.setIntensity,
                        ),
                      ),
                    ],
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: const Text('Album art overlay'),
                    value: _showArt,
                    activeColor: VibeColors.cyan,
                    onChanged: (v) => setState(() => _showArt = v),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
