import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../audio/native_fx.dart';
import '../../core/theme/vibe_colors.dart';
import 'visualizer_service.dart';

/// Draws real audio data from Android's Visualizer (spectrum or waveform).
class SpectrumView extends StatefulWidget {
  const SpectrumView({
    super.key,
    required this.style,
    required this.intensity,
    this.height = 120,
  });

  final VizStyle style;
  final double intensity;
  final double height;

  @override
  State<SpectrumView> createState() => _SpectrumViewState();
}

class _SpectrumViewState extends State<SpectrumView>
    with SingleTickerProviderStateMixin {
  static const int _bands = 32;
  static const int _wavePoints = 64;

  final List<double> _target = List<double>.filled(_bands, 0);
  final List<double> _cur = List<double>.filled(_bands, 0);
  final List<double> _wave = List<double>.filled(_wavePoints, 0);
  final ValueNotifier<int> _tick = ValueNotifier<int>(0);
  StreamSubscription<Map<dynamic, dynamic>>? _sub;
  late final Ticker _ticker;

  @override
  void initState() {
    super.initState();
    _sub = NativeFx.frames.listen(_onFrame, onError: (_) {});
    _ticker = createTicker(_onTick)..start();
  }

  void _onFrame(Map<dynamic, dynamic> m) {
    final fft = m['fft'];
    if (fft is List) {
      for (var i = 0; i < _bands && i < fft.length; i++) {
        _target[i] = (fft[i] as num).toDouble();
      }
    }
    final wave = m['wave'];
    if (wave is List) {
      for (var i = 0; i < _wavePoints && i < wave.length; i++) {
        _wave[i] = (wave[i] as num).toDouble();
      }
    }
  }

  void _onTick(Duration _) {
    for (var i = 0; i < _bands; i++) {
      final t = (_target[i] * widget.intensity).clamp(0.0, 1.0);
      // Fast attack, slow decay so bars fall smoothly.
      _cur[i] = t > _cur[i] ? t : _cur[i] * 0.86 + t * 0.14;
    }
    _tick.value++;
  }

  @override
  void dispose() {
    _sub?.cancel();
    _ticker.dispose();
    _tick.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox(
        height: widget.height,
        width: double.infinity,
        child: CustomPaint(
          painter: _VizPainter(
            style: widget.style,
            bars: _cur,
            wave: _wave,
            intensity: widget.intensity,
            repaint: _tick,
          ),
        ),
      ),
    );
  }
}

class _VizPainter extends CustomPainter {
  _VizPainter({
    required this.style,
    required this.bars,
    required this.wave,
    required this.intensity,
    required Listenable repaint,
  }) : super(repaint: repaint);

  final VizStyle style;
  final List<double> bars;
  final List<double> wave;
  final double intensity;

  static const _colors = [VibeColors.violet, VibeColors.cyan, VibeColors.pink];

  @override
  void paint(Canvas canvas, Size size) {
    final shader = const LinearGradient(colors: _colors)
        .createShader(Offset.zero & size);
    switch (style) {
      case VizStyle.bars:
        _bars(canvas, size, shader);
      case VizStyle.wave:
        _wave(canvas, size, shader);
      case VizStyle.circle:
        _circle(canvas, size);
    }
  }

  void _bars(Canvas canvas, Size size, Shader shader) {
    final n = bars.length;
    final slot = size.width / n;
    final w = slot * 0.62;
    final paint = Paint()..shader = shader;
    for (var i = 0; i < n; i++) {
      final h = math.max(4.0, bars[i] * size.height);
      final x = i * slot + (slot - w) / 2;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, size.height - h, w, h),
          Radius.circular(w / 2),
        ),
        paint,
      );
    }
  }

  void _wave(Canvas canvas, Size size, Shader shader) {
    final path = Path();
    final n = wave.length;
    for (var i = 0; i < n; i++) {
      final x = size.width * i / (n - 1);
      final y = size.height / 2 +
          (wave[i] * intensity).clamp(-1.0, 1.0) * size.height / 2;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..shader = shader
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeJoin = StrokeJoin.round,
    );
  }

  void _circle(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r0 = math.min(size.width, size.height) * 0.28;
    final n = bars.length;
    final paint = Paint()
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < n; i++) {
      final a = 2 * math.pi * i / n - math.pi / 2;
      final len = r0 * 0.12 + bars[i] * r0 * 0.9;
      paint.color = Color.lerp(
        VibeColors.violet,
        VibeColors.cyan,
        i / (n - 1),
      )!;
      canvas.drawLine(
        c + Offset(math.cos(a), math.sin(a)) * r0,
        c + Offset(math.cos(a), math.sin(a)) * (r0 + len),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _VizPainter old) =>
      old.style != style || old.intensity != intensity;
}
