import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../audio/player_service.dart';
import '../../audio/tag_reader.dart';
import '../../core/theme/vibe_colors.dart';
import '../../widgets/prompt.dart';
import '../effects/effects_controller.dart';
import '../effects/effects_state.dart';
import 'eq_recommender.dart';

/// Offline "AI" equalizer: analyses the playing song's real frequency balance
/// on-device and suggests EQ settings. Rule-based; no ML model, no network.
class AiEqCard extends ConsumerStatefulWidget {
  const AiEqCard({super.key});

  @override
  ConsumerState<AiEqCard> createState() => _AiEqCardState();
}

enum _View { before, after }

class _AiEqCardState extends ConsumerState<AiEqCard> {
  bool _busy = false;
  String? _error;
  EqRecommendation? _rec;
  List<double>? _after;
  List<double>? _before;
  bool _beforeEnabled = false;
  _View _view = _View.after;
  bool _applied = false;
  String _title = '';

  Future<void> _analyze() async {
    final np = ref.read(nowPlayingProvider).valueOrNull;
    if (np == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final svc = ref.read(playerServiceProvider);
    final fx = ref.read(effectsControllerProvider);
    final ctrl = ref.read(effectsControllerProvider.notifier);
    try {
      final a = await TagReader.analyze(np.id);
      if (a == null) {
        setState(() => _error =
            'Could not analyse this file (format not decodable on this phone).');
        return;
      }
      final rec = recommendEq(a);
      final params = await svc.eq.parameters;
      final freqs = [for (final b in params.bands) b.centerFrequency];
      final curve = [
        for (final g in curveForFrequencies(rec.gains, freqs))
          g.clamp(params.minDecibels, params.maxDecibels).toDouble(),
      ];
      _before = resampleCurve(fx.eqGains, curve.length);
      _beforeEnabled = fx.eqEnabled;
      _after = curve;
      _title = np.title;
      setState(() {
        _rec = rec;
        _view = _View.after;
        _applied = false;
      });
      await ctrl.setEqCurve(curve, 'AI preview');
    } catch (e) {
      setState(() => _error = 'Analysis failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _show(_View v) async {
    final ctrl = ref.read(effectsControllerProvider.notifier);
    setState(() => _view = v);
    if (v == _View.after) {
      await ctrl.setEqCurve(_after!, 'AI preview');
    } else {
      await ctrl.setEqCurve(_before!, 'Before');
      if (!_beforeEnabled) await ctrl.setEqEnabled(false);
    }
  }

  Future<void> _apply() async {
    final ctrl = ref.read(effectsControllerProvider.notifier);
    await ctrl.setEqCurve(_after!, 'AI: $_title');
    setState(() {
      _view = _View.after;
      _applied = true;
    });
  }

  Future<void> _reset() async {
    await _show(_View.before);
    setState(() {
      _rec = null;
      _applied = false;
    });
  }

  Future<void> _savePreset() async {
    final ctrl = ref.read(effectsControllerProvider.notifier);
    final name = await promptText(
      context,
      title: 'Preset name',
      initial: 'AI $_title',
    );
    if (name == null || name.trim().isEmpty) return;
    await ctrl.setEqCurve(_after!, name.trim());
    await ctrl.saveCustomPreset(name, _after!.length);
  }

  @override
  Widget build(BuildContext context) {
    final np = ref.watch(nowPlayingProvider).valueOrNull;
    final rec = _rec;
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: vibeCard(context),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: VibeColors.violet.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.auto_awesome, color: VibeColors.violet),
              const SizedBox(width: 8),
              Text(
                'AI Equalizer',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            'Analyses the playing song\'s real frequency balance on your phone '
            'and suggests EQ settings. Rule-based, no cloud, no ML model yet.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: (np == null || _busy) ? null : _analyze,
            icon: _busy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.auto_fix_high),
            label: Text(
              np == null
                  ? 'Play a song first'
                  : (_busy ? 'Analysing...' : 'AI Optimize'),
            ),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                _error!,
                style: TextStyle(color: theme.colorScheme.error, fontSize: 12),
              ),
            ),
          if (rec != null) ...[
            const SizedBox(height: 16),
            Text(
              'Character: ${rec.character}',
              style: const TextStyle(
                color: VibeColors.cyan,
                fontWeight: FontWeight.w700,
              ),
            ),
            for (final n in rec.notes)
              Text('\u2022 $n', style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 12),
            SizedBox(
              height: 90,
              child: CustomPaint(
                size: const Size(double.infinity, 90),
                painter: _CurvePainter(rec.gains),
              ),
            ),
            const SizedBox(height: 4),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('31 Hz', style: TextStyle(fontSize: 10)),
                Text('1 kHz', style: TextStyle(fontSize: 10)),
                Text('16 kHz', style: TextStyle(fontSize: 10)),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('Before'),
                  selected: _view == _View.before,
                  onSelected: (_) => _show(_View.before),
                ),
                ChoiceChip(
                  label: const Text('After'),
                  selected: _view == _View.after,
                  onSelected: (_) => _show(_View.after),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.tonalIcon(
                  onPressed: _applied ? null : _apply,
                  icon: Icon(_applied ? Icons.check : Icons.done_all),
                  label: Text(_applied ? 'Applied' : 'Apply'),
                ),
                OutlinedButton.icon(
                  onPressed: _reset,
                  icon: const Icon(Icons.restore),
                  label: const Text('Reset'),
                ),
                OutlinedButton.icon(
                  onPressed: _savePreset,
                  icon: const Icon(Icons.save),
                  label: const Text('Save preset'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text(
              'You can still fine-tune any band by hand below.',
              style: TextStyle(fontSize: 11),
            ),
          ],
        ],
      ),
    );
  }
}

class _CurvePainter extends CustomPainter {
  _CurvePainter(this.gains);

  final List<double> gains;

  @override
  void paint(Canvas canvas, Size size) {
    final mid = size.height / 2;
    canvas.drawLine(
      Offset(0, mid),
      Offset(size.width, mid),
      Paint()
        ..color = VibeColors.outlineVariant
        ..strokeWidth = 1,
    );
    final n = gains.length;
    final slot = size.width / n;
    final w = slot * 0.5;
    for (var i = 0; i < n; i++) {
      final h = (gains[i] / 6).clamp(-1.0, 1.0) * (mid - 4);
      final r = Rect.fromLTWH(
        i * slot + (slot - w) / 2,
        h >= 0 ? mid - h : mid,
        w,
        h.abs().clamp(2.0, 999.0),
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(3)),
        Paint()..color = h >= 0 ? VibeColors.cyan : VibeColors.pink,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CurvePainter old) => old.gains != gains;
}
