import 'dart:math' as math;

/// Octave-band centres (Hz) used by the native analyser.
const List<double> kAiBandHz = [
  31.25,
  62.5,
  125,
  250,
  500,
  1000,
  2000,
  4000,
  8000,
  16000,
];

/// Heuristic "balanced mix" profile (dB relative to the average) per band.
/// This is a hand-tuned reference, not a trained model.
const List<double> kTargetProfile = [-3, 2, 3.5, 3, 1.5, 0, -1.5, -3.5, -6, -10];

class AudioAnalysis {
  const AudioAnalysis({
    required this.bandsDb,
    required this.rmsDb,
    required this.peakDb,
  });

  factory AudioAnalysis.fromMap(Map<dynamic, dynamic> m) {
    final raw = (m['bandsDb'] as List?) ?? const [];
    return AudioAnalysis(
      bandsDb: [for (final v in raw) (v as num).toDouble()],
      rmsDb: (m['rmsDb'] as num?)?.toDouble() ?? -60,
      peakDb: (m['peakDb'] as num?)?.toDouble() ?? 0,
    );
  }

  /// Average power per octave band, in dB (below -100 means "no data").
  final List<double> bandsDb;
  final double rmsDb;
  final double peakDb;

  double get crestDb => peakDb - rmsDb;
}

class EqRecommendation {
  const EqRecommendation({
    required this.gains,
    required this.character,
    required this.notes,
  });

  /// Suggested gain (dB) for each of [kAiBandHz].
  final List<double> gains;
  final String character;
  final List<String> notes;
}

double _mean(Iterable<double> v) =>
    v.isEmpty ? 0 : v.reduce((a, b) => a + b) / v.length;

/// Suggests EQ gains by comparing the song's measured spectral balance with
/// [kTargetProfile]. [strength] 0..1 controls how far it corrects.
EqRecommendation recommendEq(
  AudioAnalysis a, {
  double strength = 0.5,
  double maxGain = 6,
}) {
  final n = kAiBandHz.length;
  if (a.bandsDb.length != n) {
    return const EqRecommendation(
      gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      character: 'Unknown',
      notes: ['Analysis data was incomplete.'],
    );
  }
  final valid = [for (final v in a.bandsDb) v > -100];
  final measuredMean = _mean([
    for (var i = 0; i < n; i++)
      if (valid[i]) a.bandsDb[i],
  ]);
  final targetMean = _mean([
    for (var i = 0; i < n; i++)
      if (valid[i]) kTargetProfile[i],
  ]);

  final diff = List<double>.filled(n, 0);
  for (var i = 0; i < n; i++) {
    if (!valid[i]) continue;
    final rel = a.bandsDb[i] - measuredMean;
    final target = kTargetProfile[i] - targetMean;
    diff[i] = target - rel;
  }

  var gains = [
    for (var i = 0; i < n; i++) (diff[i] * strength).clamp(-maxGain, maxGain),
  ];

  // Light smoothing so neighbouring bands do not jump.
  gains = [
    for (var i = 0; i < n; i++)
      0.25 * gains[math.max(0, i - 1)] +
          0.5 * gains[i] +
          0.25 * gains[math.min(n - 1, i + 1)],
  ];

  final notes = <String>[];
  final crest = a.crestDb;
  if (crest < 8 || a.peakDb > -1) {
    gains = [for (final g in gains) g > 0 ? math.min(g * 0.6, 3.0) : g];
    notes.add('Loud, compressed track: boosts were limited to avoid clipping.');
  }

  final low = _mean(diff.sublist(0, 3));
  final high = _mean(diff.sublist(7, 10));
  String character;
  if (low.abs() >= high.abs() && low.abs() > 3) {
    if (low < 0) {
      character = 'Bass-heavy';
      notes.add('Strong low end, so low bands are reduced.');
    } else {
      character = 'Thin low end';
      notes.add('Light bass, so low bands are lifted.');
    }
  } else if (high.abs() > 3) {
    if (high < 0) {
      character = 'Bright';
      notes.add('Prominent highs, so top bands are softened.');
    } else {
      character = 'Dark / dull';
      notes.add('Subdued highs, so top bands are lifted.');
    }
  } else {
    character = 'Balanced';
    notes.add('Already close to a balanced profile, so changes are small.');
  }
  return EqRecommendation(gains: gains, character: character, notes: notes);
}

/// Interpolates [gains] (defined at [kAiBandHz]) at arbitrary [freqs] on a
/// log-frequency axis, e.g. the device equalizer's centre frequencies.
List<double> curveForFrequencies(List<double> gains, List<double> freqs) {
  double at(double f) {
    if (f <= kAiBandHz.first) return gains.first;
    if (f >= kAiBandHz.last) return gains.last;
    for (var i = 0; i < kAiBandHz.length - 1; i++) {
      if (f <= kAiBandHz[i + 1]) {
        final t = (math.log(f) - math.log(kAiBandHz[i])) /
            (math.log(kAiBandHz[i + 1]) - math.log(kAiBandHz[i]));
        return gains[i] + (gains[i + 1] - gains[i]) * t;
      }
    }
    return gains.last;
  }

  return [for (final f in freqs) at(f)];
}
