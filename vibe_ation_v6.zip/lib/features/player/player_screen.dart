import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:path/path.dart' as p;

import '../../audio/player_service.dart';
import '../../core/theme/theme_controller.dart';
import '../../core/theme/theme_settings.dart';
import '../../core/theme/vibe_colors.dart';
import '../../widgets/prompt.dart';
import '../../widgets/track_art.dart';
import '../effects/effects_controller.dart';
import '../artist/artist_screen.dart';
import '../library/library_controller.dart';
import '../lyrics/lyrics_screen.dart';
import '../visualizer/spectrum_view.dart';
import '../visualizer/visualizer_screen.dart';
import '../visualizer/visualizer_service.dart';

class PlayerScreen extends ConsumerStatefulWidget {
  const PlayerScreen({super.key});

  @override
  ConsumerState<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends ConsumerState<PlayerScreen> {
  StreamSubscription<PlaybackEvent>? _errSub;
  late final VisualizerService _viz;
  bool _vizOn = false;

  Future<void> _toggleViz() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_vizOn) {
      setState(() => _vizOn = false);
      await _viz.release();
      return;
    }
    final err = await _viz.acquire();
    if (!mounted) {
      if (err == null) await _viz.release();
      return;
    }
    if (err != null) {
      messenger.showSnackBar(SnackBar(content: Text(err)));
      return;
    }
    setState(() => _vizOn = true);
  }

  @override
  void initState() {
    super.initState();
    _viz = ref.read(visualizerServiceProvider);
    _errSub = ref.read(playerServiceProvider).player.playbackEventStream.listen(
      (_) {},
      onError: (Object e, StackTrace st) {
        if (!mounted) return;
        final msg = e is PlayerException ? (e.message ?? 'code ${e.code}') : '$e';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Playback error: $msg')),
        );
      },
    );
  }

  @override
  void dispose() {
    _errSub?.cancel();
    if (_vizOn) _viz.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final svc = ref.watch(playerServiceProvider);
    final settings = ref.watch(themeControllerProvider);
    final np = ref.watch(nowPlayingProvider).valueOrNull;
    final lib = ref.watch(libraryControllerProvider);
    final fx = ref.watch(effectsControllerProvider);

    if (np == null) {
      return Scaffold(
        appBar: AppBar(leading: const BackButton()),
        body: const Center(child: Text('Nothing playing. Pick a song first.')),
      );
    }

    final artPath = np.artUri?.toFilePath();
    final fav = lib.favorites.contains(np.id);
    final ext = p.extension(np.id).replaceFirst('.', '').toUpperCase();

    return Scaffold(
      body: SafeArea(
        child: StreamBuilder<PlayerState>(
          stream: svc.player.playerStateStream,
          builder: (context, snap) {
            final playing = snap.data?.playing ?? false;
            final spinning =
                playing && settings.vinylSpin && !settings.performanceMode;
            return LayoutBuilder(
              builder: (context, c) {
                final art = (c.maxWidth - 48).clamp(180.0, 340.0);
                final artSize = settings.playerMode == PlayerMode.minimal
                    ? art * 0.55
                    : art;
                return SingleChildScrollView(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: c.maxHeight),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                      child: Column(
                        children: [
                          _TopBar(
                            format: ext,
                            onQueue: () => _showQueue(context, svc),
                          ),
                          const SizedBox(height: 16),
                          if (settings.playerMode == PlayerMode.vinyl)
                            _Turntable(
                              size: artSize,
                              spinning: spinning,
                              playing: playing,
                              artPath: artPath,
                            )
                          else
                            _ArtCard(size: artSize, artPath: artPath),
                          if (_vizOn) const _VizPanel(),
                          const SizedBox(height: 20),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      np.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineSmall
                                          ?.copyWith(fontWeight: FontWeight.w800),
                                    ),
                                    const SizedBox(height: 4),
                                    InkWell(
                                      onTap: () => openArtist(
                                        context,
                                        np.artist ?? 'Unknown artist',
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Flexible(
                                            child: Text(
                                              np.artist ?? 'Unknown artist',
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                color: VibeColors.lavender,
                                                fontWeight: FontWeight.w600,
                                                decoration:
                                                    TextDecoration.underline,
                                                decorationColor:
                                                    VibeColors.lavender,
                                              ),
                                            ),
                                          ),
                                          const Icon(
                                            Icons.chevron_right,
                                            size: 18,
                                            color: VibeColors.lavender,
                                          ),
                                        ],
                                      ),
                                    ),
                                    if ((np.album ?? '').isNotEmpty)
                                      Text(
                                        np.album!,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall,
                                      ),
                                  ],
                                ),
                              ),
                              IconButton.filledTonal(
                                tooltip: 'Favorite',
                                icon: Icon(
                                  fav ? Icons.favorite : Icons.favorite_border,
                                  color: VibeColors.pink,
                                ),
                                onPressed: () => ref
                                    .read(libraryControllerProvider.notifier)
                                    .toggleFavorite(np.id),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _SeekBar(player: svc.player),
                          const SizedBox(height: 8),
                          _Controls(svc: svc, playing: playing),
                          const _NextUp(),
                          const SizedBox(height: 16),
                          _FeatureChips(
                            vizOn: _vizOn,
                            onViz: settings.performanceMode ? null : _toggleViz,
                            vinyl: settings.playerMode == PlayerMode.vinyl,
                            slowed: fx.speed < 1.0,
                            onVinyl: () => ref
                                .read(themeControllerProvider.notifier)
                                .setPlayerMode(
                                  settings.playerMode == PlayerMode.vinyl
                                      ? PlayerMode.album
                                      : PlayerMode.vinyl,
                                ),
                            onSlowed: () {
                              final ctrl =
                                  ref.read(effectsControllerProvider.notifier);
                              if (fx.speed < 1.0) {
                                ctrl.setSpeed(1.0);
                                ctrl.setPitch(1.0);
                              } else {
                                ctrl.applySlowed();
                              }
                            },
                            onLyrics: () => Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) => const LyricsScreen(),
                              ),
                            ),
                            onQueue: () => _showQueue(context, svc),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.folder_open, size: 16),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(
                                  p.dirname(np.id),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  void _showQueue(BuildContext context, PlayerService svc) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        builder: (ctx, scroll) => StreamBuilder<SequenceState?>(
          stream: svc.player.sequenceStateStream,
          builder: (ctx, snap) {
            final seq = snap.data?.sequence ?? const [];
            final cur = snap.data?.currentIndex;
            return Column(
              children: [
                ListTile(
                  title: const Text('Queue'),
                  trailing: TextButton(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await svc.clearQueue();
                    },
                    child: const Text('Clear'),
                  ),
                ),
                Expanded(
                  child: ReorderableListView.builder(
                    scrollController: scroll,
                    itemCount: seq.length,
                    onReorder: (a, b) {
                      if (b > a) b -= 1;
                      svc.moveInQueue(a, b);
                    },
                    itemBuilder: (ctx, i) {
                      final item = seq[i].tag as MediaItem;
                      return ListTile(
                        key: ValueKey('$i-${item.id}'),
                        selected: i == cur,
                        leading: TrackArt(
                          seed: item.title,
                          artPath: item.artUri?.toFilePath(),
                          size: 44,
                        ),
                        title: Text(item.title, maxLines: 1),
                        subtitle: Text(
                          cur != null && i == cur + 1
                              ? 'Next up'
                              : (item.artist ?? ''),
                        ),
                        onTap: () => svc.playQueueIndex(i),
                        trailing: IconButton(
                          icon: const Icon(Icons.close),
                          tooltip: 'Remove from queue',
                          onPressed: () => svc.removeFromQueue(i),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.format, required this.onQueue});

  final String format;
  final VoidCallback onQueue;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton.filledTonal(
          tooltip: 'Close',
          icon: const Icon(Icons.keyboard_arrow_down),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
        Expanded(
          child: Column(
            children: [
              const Text(
                '\u2022 NOW PLAYING',
                style: TextStyle(
                  fontSize: 12,
                  letterSpacing: 3,
                  color: VibeColors.cyan,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              if (format.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: VibeColors.cyan.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: VibeColors.cyan.withOpacity(0.4)),
                  ),
                  child: Text(
                    format,
                    style: const TextStyle(
                      color: VibeColors.cyan,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
        ),
        IconButton.filledTonal(
          tooltip: 'Queue',
          icon: const Icon(Icons.queue_music),
          onPressed: onQueue,
        ),
      ],
    );
  }
}

class _ArtCard extends StatelessWidget {
  const _ArtCard({required this.size, required this.artPath});

  final double size;
  final String? artPath;

  @override
  Widget build(BuildContext context) {
    final cover = artPath;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: VibeColors.outlineVariant, width: 2),
        boxShadow: [
          BoxShadow(
            color: VibeColors.violet.withOpacity(0.35),
            blurRadius: 40,
            spreadRadius: 2,
          ),
        ],
        gradient: const LinearGradient(
          colors: [Color(0xFF1F1F25), Color(0xFF0E0E13)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: cover != null
            ? Image.file(
                File(cover),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _logo(),
              )
            : _logo(),
      ),
    );
  }

  Widget _logo() => Padding(
        padding: EdgeInsets.all(size * 0.18),
        child: Image.asset(
          'assets/images/logo.png',
          errorBuilder: (_, __, ___) =>
              const Icon(Icons.music_note, size: 72, color: Colors.white54),
        ),
      );
}

class _Turntable extends StatefulWidget {
  const _Turntable({
    required this.size,
    required this.spinning,
    required this.playing,
    required this.artPath,
  });

  final double size;
  final bool spinning;
  final bool playing;
  final String? artPath;

  @override
  State<_Turntable> createState() => _TurntableState();
}

class _TurntableState extends State<_Turntable>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  );

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant _Turntable old) {
    super.didUpdateWidget(old);
    _sync();
  }

  void _sync() {
    if (widget.spinning) {
      if (!_c.isAnimating) _c.repeat();
    } else {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    final label = s * 0.36;
    final cover = widget.artPath;
    return SizedBox(
      width: s,
      height: s,
      child: Stack(
        alignment: Alignment.center,
        children: [
          RotationTransition(
            turns: _c,
            child: Container(
              width: s * 0.92,
              height: s * 0.92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black,
                boxShadow: [
                  BoxShadow(
                    color: VibeColors.violet.withOpacity(0.3),
                    blurRadius: 30,
                  ),
                ],
              ),
              child: CustomPaint(
                painter: _GroovePainter(),
                child: Center(
                  child: Container(
                    width: label,
                    height: label,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: VibeColors.cyan, width: 2),
                      gradient: const LinearGradient(
                        colors: [VibeColors.violet, VibeColors.cyan],
                      ),
                    ),
                    child: ClipOval(
                      child: cover != null
                          ? Image.file(
                              File(cover),
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const SizedBox(),
                            )
                          : Padding(
                              padding: EdgeInsets.all(label * 0.12),
                              child: Image.asset(
                                'assets/images/logo.png',
                                errorBuilder: (_, __, ___) => const SizedBox(),
                              ),
                            ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          AnimatedRotation(
            turns: widget.playing ? 0 : -0.07,
            duration: const Duration(milliseconds: 600),
            alignment: const Alignment(0.78, -0.8),
            child: CustomPaint(size: Size(s, s), painter: _ArmPainter()),
          ),
        ],
      ),
    );
  }
}

class _GroovePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (var i = 0; i < 14; i++) {
      final rr = r * (0.42 + i * 0.04);
      paint.color = Colors.white.withOpacity(i.isEven ? 0.07 : 0.03);
      canvas.drawCircle(c, rr, paint);
    }
    final sheen = Paint()
      ..shader = SweepGradient(
        colors: [
          Colors.transparent,
          VibeColors.cyan.withOpacity(0.12),
          Colors.transparent,
          VibeColors.violet.withOpacity(0.12),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r, sheen);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class _ArmPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final pivot = Offset(w * 0.89, h * 0.10);
    final head = Offset(w * 0.64, h * 0.68);
    final arm = Paint()
      ..color = Colors.white70
      ..strokeWidth = w * 0.015
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(pivot, head, arm);
    canvas.drawCircle(pivot, w * 0.06, Paint()..color = const Color(0xFF2A292F));
    canvas.drawCircle(pivot, w * 0.03, Paint()..color = Colors.black);
    canvas.save();
    canvas.translate(head.dx, head.dy);
    canvas.rotate(0.45);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset.zero, width: w * 0.06, height: w * 0.10),
        const Radius.circular(4),
      ),
      Paint()..color = VibeColors.cyan,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class _NextUp extends ConsumerWidget {
  const _NextUp();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final svc = ref.watch(playerServiceProvider);
    return StreamBuilder<SequenceState?>(
      stream: svc.player.sequenceStateStream,
      builder: (context, snap) {
        final s = snap.data;
        final i = s?.currentIndex;
        if (s == null || i == null || i + 1 >= s.sequence.length) {
          return const SizedBox.shrink();
        }
        final next = s.sequence[i + 1].tag as MediaItem;
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(
            'Next: ${next.title}',
            style: Theme.of(context).textTheme.bodySmall,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        );
      },
    );
  }
}

class _SeekBar extends StatelessWidget {
  const _SeekBar({required this.player});

  final AudioPlayer player;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration?>(
      stream: player.durationStream,
      builder: (context, dSnap) {
        final total = dSnap.data ?? Duration.zero;
        return StreamBuilder<Duration>(
          stream: player.positionStream,
          builder: (context, pSnap) {
            final pos = pSnap.data ?? Duration.zero;
            final maxMs = total.inMilliseconds.toDouble();
            final value = pos.inMilliseconds
                .toDouble()
                .clamp(0, maxMs > 0 ? maxMs : 1)
                .toDouble();
            return Column(
              children: [
                Slider(
                  value: value,
                  max: maxMs > 0 ? maxMs : 1,
                  onChanged: maxMs > 0
                      ? (v) => player.seek(Duration(milliseconds: v.round()))
                      : null,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        formatDuration(pos),
                        style: const TextStyle(color: VibeColors.cyan),
                      ),
                      Text(formatDuration(total)),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.svc, required this.playing});

  final PlayerService svc;
  final bool playing;

  @override
  Widget build(BuildContext context) {
    final player = svc.player;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        StreamBuilder<bool>(
          stream: player.shuffleModeEnabledStream,
          builder: (context, s) => IconButton.outlined(
            tooltip: 'Shuffle',
            icon: Icon(
              Icons.shuffle,
              color: (s.data ?? false) ? VibeColors.cyan : null,
            ),
            onPressed: svc.toggleShuffle,
          ),
        ),
        IconButton(
          iconSize: 40,
          tooltip: 'Previous',
          icon: const Icon(Icons.skip_previous),
          onPressed: svc.previous,
        ),
        GestureDetector(
          onTap: svc.togglePlay,
          child: Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [VibeColors.violet, VibeColors.cyan],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: VibeColors.violet.withOpacity(0.5),
                  blurRadius: 24,
                ),
              ],
            ),
            child: Icon(
              playing ? Icons.pause : Icons.play_arrow,
              size: 46,
              color: const Color(0xFF1B0050),
            ),
          ),
        ),
        IconButton(
          iconSize: 40,
          tooltip: 'Next',
          icon: const Icon(Icons.skip_next),
          onPressed: svc.next,
        ),
        StreamBuilder<LoopMode>(
          stream: player.loopModeStream,
          builder: (context, s) {
            final mode = s.data ?? LoopMode.off;
            return IconButton.outlined(
              tooltip: 'Repeat',
              icon: Icon(
                mode == LoopMode.one ? Icons.repeat_one : Icons.repeat,
                color: mode == LoopMode.off ? null : VibeColors.cyan,
              ),
              onPressed: svc.cycleLoopMode,
            );
          },
        ),
      ],
    );
  }
}

class _FeatureChips extends StatelessWidget {
  const _FeatureChips({
    required this.vizOn,
    required this.onViz,
    required this.vinyl,
    required this.slowed,
    required this.onVinyl,
    required this.onSlowed,
    required this.onLyrics,
    required this.onQueue,
  });

  final bool vizOn;
  final VoidCallback? onViz;
  final bool vinyl;
  final bool slowed;
  final VoidCallback onVinyl;
  final VoidCallback onSlowed;
  final VoidCallback onLyrics;
  final VoidCallback onQueue;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: vibeCard(context),
        borderRadius: BorderRadius.circular(24),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _chip(Icons.album, 'Vinyl Mode', vinyl, onVinyl),
            _chip(Icons.graphic_eq, 'Visualizer', vizOn, onViz),
            _chip(Icons.slow_motion_video, 'Slowed', slowed, onSlowed),
            _chip(Icons.lyrics_outlined, 'Lyrics', false, onLyrics),
            _chip(Icons.queue_music, 'Queue', false, onQueue),
          ],
        ),
      ),
    );
  }

  Widget _chip(IconData icon, String label, bool selected, VoidCallback? tap) {
    final enabled = tap != null;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: tap,
        child: Container(
          width: 96,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: selected
                ? VibeColors.cyan.withOpacity(0.15)
                : Colors.white.withOpacity(0.04),
            border: Border.all(
              color: selected ? VibeColors.cyan : Colors.transparent,
            ),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: !enabled
                    ? VibeColors.outline.withOpacity(0.5)
                    : (selected ? VibeColors.cyan : VibeColors.onSurfaceVariant),
              ),
              const SizedBox(height: 6),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  color: enabled ? null : VibeColors.outline.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _VizPanel extends ConsumerWidget {
  const _VizPanel();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final prefs = ref.watch(vizPrefsProvider);
    final ctrl = ref.read(vizPrefsProvider.notifier);
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Column(
        children: [
          SpectrumView(
            style: prefs.style,
            intensity: prefs.intensity,
            height: 96,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (final s in VizStyle.values)
                IconButton(
                  tooltip: s.name,
                  isSelected: prefs.style == s,
                  icon: Icon(switch (s) {
                    VizStyle.bars => Icons.equalizer,
                    VizStyle.wave => Icons.show_chart,
                    VizStyle.circle => Icons.radio_button_unchecked,
                  }),
                  onPressed: () => ctrl.setStyle(s),
                ),
              IconButton(
                tooltip: 'Fullscreen',
                icon: const Icon(Icons.fullscreen),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    fullscreenDialog: true,
                    builder: (_) => const VisualizerScreen(),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
