import '../../core/models/track.dart';

final RegExp _splitter = RegExp(r'\s*(?:;|/|\sfeat\.?\s|\sft\.?\s)\s*', caseSensitive: false);

/// Splits "A; B", "A / B", "A feat. B" into separate artist names.
List<String> splitArtists(String artist) {
  final parts = artist
      .split(_splitter)
      .map((s) => s.trim())
      .where((s) => s.isNotEmpty)
      .toList();
  return parts.isEmpty ? [artist.trim()] : parts;
}

String artistKey(String name) => name.trim().toLowerCase();

/// Tracks where [name] is one of the artists.
List<Track> tracksByArtist(List<Track> tracks, String name) {
  final key = artistKey(name);
  return [
    for (final t in tracks)
      if (splitArtists(t.artist).any((a) => artistKey(a) == key)) t,
  ];
}

/// Artist display name -> number of tracks, one entry per distinct artist.
Map<String, int> artistCounts(List<Track> tracks) {
  final display = <String, String>{};
  final counts = <String, int>{};
  for (final t in tracks) {
    for (final a in splitArtists(t.artist)) {
      final k = artistKey(a);
      display.putIfAbsent(k, () => a);
      counts[k] = (counts[k] ?? 0) + 1;
    }
  }
  return {for (final e in counts.entries) display[e.key]!: e.value};
}
