import '../../core/models/track.dart';

enum SortKey { title, artist, album, duration, dateAdded }

const Map<String, String> _fold = {
  'á': 'a', 'à': 'a', 'â': 'a', 'ä': 'a', 'ã': 'a', 'å': 'a',
  'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e',
  'í': 'i', 'ì': 'i', 'î': 'i', 'ï': 'i',
  'ó': 'o', 'ò': 'o', 'ô': 'o', 'ö': 'o', 'õ': 'o',
  'ú': 'u', 'ù': 'u', 'û': 'u', 'ü': 'u',
  'ç': 'c', 'ñ': 'n', 'ß': 'ss',
};

final RegExp _leadingJunk = RegExp(r'^[^\p{L}\p{N}]+', unicode: true);
final RegExp _chunks = RegExp(r'(\d+|\D+)');

/// Lower-cases, folds common accents, drops leading punctuation and the
/// articles "the", "a", "an" so "The Weeknd" sorts under W.
String sortText(String input) {
  final b = StringBuffer();
  for (final ch in input.toLowerCase().trim().split('')) {
    b.write(_fold[ch] ?? ch);
  }
  var t = b.toString().replaceFirst(_leadingJunk, '');
  for (final article in const ['the ', 'an ', 'a ']) {
    if (t.startsWith(article) && t.length > article.length) {
      t = t.substring(article.length);
      break;
    }
  }
  return t;
}

/// Natural comparison: "Track 2" < "Track 10".
int naturalCompare(String a, String b) {
  final ca = _chunks.allMatches(a).map((m) => m.group(0)!).toList();
  final cb = _chunks.allMatches(b).map((m) => m.group(0)!).toList();
  final n = ca.length < cb.length ? ca.length : cb.length;
  for (var i = 0; i < n; i++) {
    final x = ca[i];
    final y = cb[i];
    final xn = int.tryParse(x);
    final yn = int.tryParse(y);
    int c;
    if (xn != null && yn != null) {
      final xs = x.replaceFirst(RegExp(r'^0+(?=.)'), '');
      final ys = y.replaceFirst(RegExp(r'^0+(?=.)'), '');
      c = xs.length != ys.length
          ? xs.length.compareTo(ys.length)
          : xs.compareTo(ys);
    } else {
      c = x.compareTo(y);
    }
    if (c != 0) return c;
  }
  return ca.length.compareTo(cb.length);
}

bool _isUnknownArtist(Track t) =>
    t.artist.trim().isEmpty || t.artist.toLowerCase() == 'unknown artist';

/// Sorts a copy of [src]. Tracks missing the sort value (unknown artist, no
/// album, no duration) always go last, whatever the direction.
List<Track> sortTracks(List<Track> src, SortKey key, bool ascending) {
  final out = List<Track>.of(src);
  int dir(int c) => ascending ? c : -c;

  bool missing(Track t) {
    switch (key) {
      case SortKey.artist:
        return _isUnknownArtist(t);
      case SortKey.album:
        return (t.album ?? '').trim().isEmpty;
      case SortKey.duration:
        return t.durationMs == null;
      case SortKey.title:
      case SortKey.dateAdded:
        return false;
    }
  }

  int primary(Track a, Track b) {
    switch (key) {
      case SortKey.title:
        return naturalCompare(sortText(a.title), sortText(b.title));
      case SortKey.artist:
        return naturalCompare(sortText(a.artist), sortText(b.artist));
      case SortKey.album:
        return naturalCompare(sortText(a.album ?? ''), sortText(b.album ?? ''));
      case SortKey.duration:
        return (a.durationMs ?? 0).compareTo(b.durationMs ?? 0);
      case SortKey.dateAdded:
        return a.addedAt.compareTo(b.addedAt);
    }
  }

  out.sort((a, b) {
    final ma = missing(a);
    final mb = missing(b);
    if (ma != mb) return ma ? 1 : -1;
    final c = ma ? 0 : dir(primary(a, b));
    if (c != 0) return c;
    final t = naturalCompare(sortText(a.title), sortText(b.title));
    return t != 0 ? t : a.path.compareTo(b.path);
  });
  return out;
}

String sortLabel(SortKey key, bool ascending) {
  switch (key) {
    case SortKey.title:
      return ascending ? 'Title (A\u2013Z)' : 'Title (Z\u2013A)';
    case SortKey.artist:
      return ascending ? 'Artist (A\u2013Z)' : 'Artist (Z\u2013A)';
    case SortKey.album:
      return ascending ? 'Album (A\u2013Z)' : 'Album (Z\u2013A)';
    case SortKey.duration:
      return ascending ? 'Duration (shortest)' : 'Duration (longest)';
    case SortKey.dateAdded:
      return ascending ? 'Date added (oldest)' : 'Date added (newest)';
  }
}
