import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'sort_controller.dart';
import 'sorting.dart';

String _keyName(SortKey k) {
  switch (k) {
    case SortKey.title:
      return 'Title';
    case SortKey.artist:
      return 'Artist';
    case SortKey.album:
      return 'Album';
    case SortKey.duration:
      return 'Duration';
    case SortKey.dateAdded:
      return 'Date added';
  }
}

/// Shows the current sort and lets the user pick another. Choosing the
/// selected option again reverses the direction.
class SortMenuButton extends ConsumerWidget {
  const SortMenuButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(sortControllerProvider);
    final ctrl = ref.read(sortControllerProvider.notifier);
    return PopupMenuButton<SortKey>(
      tooltip: 'Sort (choose again to reverse)',
      onSelected: ctrl.setKey,
      itemBuilder: (_) => [
        for (final k in SortKey.values)
          CheckedPopupMenuItem<SortKey>(
            value: k,
            checked: k == s.key,
            child: Text(
              k == s.key
                  ? '${_keyName(k)}  ${s.ascending ? '\u2191' : '\u2193'}'
                  : _keyName(k),
            ),
          ),
      ],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.sort, size: 18),
            const SizedBox(width: 4),
            Text(
              sortLabel(s.key, s.ascending),
              style: const TextStyle(fontSize: 13),
            ),
            const Icon(Icons.arrow_drop_down),
          ],
        ),
      ),
    );
  }
}
