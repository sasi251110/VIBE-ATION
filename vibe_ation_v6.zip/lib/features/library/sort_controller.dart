import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/theme_controller.dart';
import 'sorting.dart';

class SortState {
  const SortState({this.key = SortKey.title, this.ascending = true});

  final SortKey key;
  final bool ascending;
}

final sortControllerProvider =
    NotifierProvider<SortController, SortState>(SortController.new);

class SortController extends Notifier<SortState> {
  static const _kKey = 'library.sort.key';
  static const _kAsc = 'library.sort.asc';

  @override
  SortState build() {
    final prefs = ref.watch(sharedPreferencesProvider);
    final key = SortKey.values.firstWhere(
      (k) => k.name == prefs.getString(_kKey),
      orElse: () => SortKey.title,
    );
    return SortState(key: key, ascending: prefs.getBool(_kAsc) ?? true);
  }

  Future<void> setKey(SortKey key) async {
    // Picking the active key again flips direction; a new key keeps it
    // ascending (except date added, which defaults to newest first).
    final asc = key == state.key
        ? !state.ascending
        : key != SortKey.dateAdded;
    state = SortState(key: key, ascending: asc);
    await _save();
  }

  Future<void> toggleDirection() async {
    state = SortState(key: state.key, ascending: !state.ascending);
    await _save();
  }

  Future<void> _save() async {
    final prefs = ref.read(sharedPreferencesProvider);
    await prefs.setString(_kKey, state.key.name);
    await prefs.setBool(_kAsc, state.ascending);
  }
}
