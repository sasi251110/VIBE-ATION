import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vibe_colors.dart';
import '../../widgets/track_art.dart';
import '../library/artist_utils.dart';
import '../library/library_controller.dart';
import '../library/library_screen.dart';
import '../library/sorting.dart';

/// Opens the artist page; if the credit has several artists, asks which one.
Future<void> openArtist(BuildContext context, String artist) async {
  final names = splitArtists(artist);
  var chosen = names.first;
  if (names.length > 1) {
    final pick = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Which artist?'),
        children: [
          for (final n in names)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, n),
              child: Text(n),
            ),
        ],
      ),
    );
    if (pick == null) return;
    chosen = pick;
  }
  if (!context.mounted) return;
  await Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => ArtistScreen(name: chosen)),
  );
}

class ArtistScreen extends ConsumerWidget {
  const ArtistScreen({super.key, required this.name});

  final String name;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lib = ref.watch(libraryControllerProvider);
    final tracks = sortTracks(
      tracksByArtist(lib.tracks, name),
      SortKey.album,
      true,
    );
    final first = tracks.isEmpty ? null : tracks.first;

    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                TrackArt(
                  seed: name,
                  artPath: first?.artPath,
                  size: 88,
                  radius: 44,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                      Text(
                        '${tracks.length} song${tracks.length == 1 ? '' : 's'}',
                        style: const TextStyle(color: VibeColors.cyan),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          FilledButton.icon(
                            onPressed: tracks.isEmpty
                                ? null
                                : () => playFrom(context, ref, tracks, 0),
                            icon: const Icon(Icons.play_arrow),
                            label: const Text('Play'),
                          ),
                          const SizedBox(width: 8),
                          OutlinedButton.icon(
                            onPressed: tracks.isEmpty
                                ? null
                                : () {
                                    final list = [...tracks]..shuffle();
                                    playFrom(context, ref, list, 0);
                                  },
                            icon: const Icon(Icons.shuffle),
                            label: const Text('Shuffle'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: TrackList(tracks: tracks, empty: 'No songs by this artist.'),
          ),
        ],
      ),
    );
  }
}
