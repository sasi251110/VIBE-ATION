import 'package:flutter_test/flutter_test.dart';
import 'package:vibe_ation/core/models/track.dart';
import 'package:vibe_ation/features/library/artist_utils.dart';
import 'package:vibe_ation/features/library/sorting.dart';

Track t(String title, {String artist = 'Unknown artist', String? album, int? dur, int added = 0}) =>
    Track(
      path: '/m/$title.mp3',
      title: title,
      artist: artist,
      album: album,
      durationMs: dur,
      addedAt: added,
    );

List<String> titles(List<Track> l) => [for (final x in l) x.title];

void main() {
  test('naturalCompare orders numbers numerically', () {
    expect(naturalCompare('track 2', 'track 10') < 0, isTrue);
    expect(naturalCompare('track 10', 'track 2') > 0, isTrue);
    expect(naturalCompare('a01', 'a1'), 0);
    expect(naturalCompare('abc', 'abd') < 0, isTrue);
  });

  test('sortText ignores case, accents, punctuation and leading articles', () {
    expect(sortText('The Weeknd'), 'weeknd');
    expect(sortText('A Sky Full'), 'sky full');
    expect(sortText('  "Hello"'), 'hello"');
    expect(sortText('Beyoncé'), 'beyonce');
    expect(sortText('The'), 'the');
  });

  test('title sort is natural, case-insensitive, ascending and descending', () {
    final l = [t('banana'), t('Apple 10'), t('apple 2'), t('The Cherry')];
    expect(titles(sortTracks(l, SortKey.title, true)),
        ['apple 2', 'Apple 10', 'banana', 'The Cherry']);
    expect(titles(sortTracks(l, SortKey.title, false)),
        ['The Cherry', 'banana', 'Apple 10', 'apple 2']);
  });

  test('artist sort puts unknown artists last in both directions', () {
    final l = [
      t('1', artist: 'Zed'),
      t('2'),
      t('3', artist: 'adele'),
    ];
    expect(titles(sortTracks(l, SortKey.artist, true)), ['3', '1', '2']);
    expect(titles(sortTracks(l, SortKey.artist, false)), ['1', '3', '2']);
  });

  test('album sort puts missing albums last', () {
    final l = [t('1', album: 'B'), t('2'), t('3', album: 'a')];
    expect(titles(sortTracks(l, SortKey.album, true)), ['3', '1', '2']);
  });

  test('duration sort and missing durations last', () {
    final l = [t('long', dur: 300000), t('none'), t('short', dur: 100000)];
    expect(titles(sortTracks(l, SortKey.duration, true)),
        ['short', 'long', 'none']);
    expect(titles(sortTracks(l, SortKey.duration, false)),
        ['long', 'short', 'none']);
  });

  test('date added newest first when descending', () {
    final l = [t('old', added: 1), t('new', added: 9), t('mid', added: 5)];
    expect(titles(sortTracks(l, SortKey.dateAdded, false)),
        ['new', 'mid', 'old']);
    expect(titles(sortTracks(l, SortKey.dateAdded, true)),
        ['old', 'mid', 'new']);
  });

  test('sortLabel is readable', () {
    expect(sortLabel(SortKey.title, true), 'Title (A\u2013Z)');
    expect(sortLabel(SortKey.dateAdded, false), 'Date added (newest)');
  });

  test('splitArtists and tracksByArtist', () {
    expect(splitArtists('A; B'), ['A', 'B']);
    expect(splitArtists('A / B'), ['A', 'B']);
    expect(splitArtists('A feat. B'), ['A', 'B']);
    expect(splitArtists('Simon & Garfunkel'), ['Simon & Garfunkel']);
    final l = [
      t('1', artist: 'Adele'),
      t('2', artist: 'adele'),
      t('3', artist: 'Adele; Drake'),
      t('4', artist: 'Drake'),
    ];
    expect(titles(tracksByArtist(l, 'ADELE')), ['1', '2', '3']);
    expect(artistCounts(l)['Drake'], 2);
    expect(artistCounts(l)['Adele'], 3);
  });
}
