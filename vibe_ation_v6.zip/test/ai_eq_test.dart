import 'package:flutter_test/flutter_test.dart';
import 'package:vibe_ation/features/ai_eq/eq_recommender.dart';
import 'package:vibe_ation/features/effects/effects_state.dart';

AudioAnalysis analysisFromProfile(List<double> rel, {double rms = -18, double peak = -3}) =>
    AudioAnalysis(
      bandsDb: [for (var i = 0; i < rel.length; i++) -40 + rel[i]],
      rmsDb: rms,
      peakDb: peak,
    );

void main() {
  test('profile equal to the target gives near-zero gains and Balanced', () {
    final a = analysisFromProfile(kTargetProfile);
    final r = recommendEq(a);
    expect(r.character, 'Balanced');
    for (final g in r.gains) {
      expect(g.abs() < 0.2, isTrue);
    }
  });

  test('bass-heavy song gets reduced low bands', () {
    final p = [...kTargetProfile];
    for (var i = 0; i < 3; i++) {
      p[i] += 10;
    }
    final r = recommendEq(analysisFromProfile(p));
    expect(r.character, 'Bass-heavy');
    expect(r.gains[1] < -1, isTrue);
  });

  test('bright song gets softened highs', () {
    final p = [...kTargetProfile];
    for (var i = 7; i < 10; i++) {
      p[i] += 10;
    }
    final r = recommendEq(analysisFromProfile(p));
    expect(r.character, 'Bright');
    expect(r.gains[9] < -1, isTrue);
  });

  test('dull song gets lifted highs, capped for loud tracks', () {
    final p = [...kTargetProfile];
    for (var i = 7; i < 10; i++) {
      p[i] -= 14;
    }
    final normal = recommendEq(analysisFromProfile(p));
    expect(normal.character, 'Dark / dull');
    expect(normal.gains[9] > 1, isTrue);
    final loud = recommendEq(analysisFromProfile(p, rms: -8, peak: -0.2));
    expect(loud.gains.every((g) => g <= 3.0 + 1e-9), isTrue);
    expect(loud.notes.any((n) => n.contains('clipping')), isTrue);
  });

  test('gains never exceed +-maxGain', () {
    final p = [30.0, -30, 30, -30, 30, -30, 30, -30, 30, -30];
    final r = recommendEq(analysisFromProfile(p), strength: 1);
    expect(r.gains.every((g) => g.abs() <= 6.0 + 1e-9), isTrue);
  });

  test('incomplete analysis is handled', () {
    final r = recommendEq(const AudioAnalysis(bandsDb: [1, 2], rmsDb: -20, peakDb: -3));
    expect(r.character, 'Unknown');
    expect(r.gains.every((g) => g == 0), isTrue);
  });

  test('AudioAnalysis.fromMap', () {
    final a = AudioAnalysis.fromMap({
      'bandsDb': [1, 2.5],
      'rmsDb': -20,
      'peakDb': -2,
    });
    expect(a.bandsDb, [1.0, 2.5]);
    expect(a.crestDb, 18);
  });

  test('curveForFrequencies interpolates on log frequency', () {
    final gains = [for (var i = 0; i < 10; i++) i.toDouble()];
    final c = curveForFrequencies(gains, [20, 31.25, 1000, 16000, 20000]);
    expect(c[0], 0);
    expect(c[1], 0);
    expect(c[2], closeTo(5, 1e-9));
    expect(c[3], 9);
    expect(c[4], 9);
    final mid = curveForFrequencies(gains, [44.19])[0];
    expect(mid > 0.4 && mid < 0.6, isTrue);
  });

  test('effectiveEqGains lifts only the top bands', () {
    final g = effectiveEqGains([0, 0, 0, 0, 0], 100);
    expect(g, [0, 0, 0, 3, 6]);
    expect(effectiveEqGains([1, 1, 1], 0), [1, 1, 1]);
    expect(effectiveEqGains([0, 0], 50), [1.5, 3]);
  });

  test('EffectsState keeps bass, spatial and treble in json', () {
    const s = EffectsState(bass: 40, spatial: 25, trebleClarity: 60);
    final r = EffectsState.fromJson(s.toJson());
    expect(r.bass, 40);
    expect(r.spatial, 25);
    expect(r.trebleClarity, 60);
  });
}
